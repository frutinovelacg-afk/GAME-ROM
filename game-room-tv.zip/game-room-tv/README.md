# GAME ROOM TV

Plataforma de juegos para jugar con amigos: **Fire TV Stick = pantalla**, **celulares = controles**.
Vite (JavaScript puro) + Supabase (Auth, PostgreSQL, Realtime) + Netlify. Sin servidor propio.

## Estructura

```
game-room-tv/
├─ index.html · package.json · vite.config.js · netlify.toml · .env.example
├─ supabase/schema.sql          ← tablas, RLS, funciones, realtime (ejecutar entero)
└─ src/
   ├─ main.js · style.css · supabase.js · net.js · ui.js
   ├─ tv/tv.js                  ← modo "SOY LA TV" (sala, menú, resultados, motor de juego)
   ├─ phone/phone.js            ← modo "SOY CELULAR" (cuenta, salas, chat, perfil, resultados)
   ├─ phone/controller.js       ← mando que cambia según el juego
   └─ games/                    ← catalog, engine, input + los 12 juegos
```

## 1. Crear el proyecto Supabase
1. Entra a https://supabase.com → **New project** (plan gratis). Espera a que termine de crearse.

## 2–4. Crear tablas, ejecutar el SQL y configurar Auth
1. **SQL Editor → New query**, pega TODO `supabase/schema.sql` y pulsa **Run**.
2. **Authentication → Sign In / Providers**:
   - **Email**: activado, y **desactiva "Confirm email"** (los usuarios entran con usuario + contraseña; internamente se usa `usuario@gameroom.app`).
   - **Allow anonymous sign-ins**: **activar** (la TV inicia sesión como anónima para crear la sala).
3. Comprueba en **Database → Replication** que `rooms`, `room_players` y `chat_messages` están en la publicación `supabase_realtime` (el SQL ya lo hace).

## 5–6. URL y clave pública
**Project Settings → API**: copia **Project URL** y la clave **anon / public** (nunca la `service_role`).

## 7–8. Variables de entorno y ejecución local
```bash
cp .env.example .env     # rellena VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY
npm install
npm run dev              # http://localhost:5173
```

## 9. Desplegar en Netlify
1. Sube la carpeta a un repositorio de GitHub.
2. Netlify → **Add new site → Import from Git**.
3. Build command: `npm run build` · Publish directory: `dist` (ya está en `netlify.toml`, incluida la regla SPA).
4. **Site configuration → Environment variables**: añade `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY`.
5. **Deploy**. (También sirve arrastrar la carpeta `dist` tras `npm run build` con las variables en `.env`.)

## 10. Abrirlo en el Fire TV Stick
Abre el navegador **Silk** (o Firefox para Fire TV), entra a `https://TU-SITIO.netlify.app` y elige **📺 SOY LA TV**. Muévete con el control remoto (botón central para pulsar). La sala se crea sola y muestra el código. Si recargas la TV, recupera la misma sala.

## 11. Conectar los celulares
En cada celular abre la misma dirección (la TV la muestra abajo) → **📱 SOY CELULAR** → crear cuenta (una vez) o iniciar sesión → escribir el código → **UNIRME A LA SALA**. El primero en entrar es 👑 ADMIN: elige el juego y lo inicia desde su celular. Si el admin sale, pasa al siguiente jugador.

## 12. Probar 2, 3 y 4 jugadores
- **2 jugadores**: TV + 2 celulares, o 1 celular + 1 pestaña de PC.
- **3–4**: en un solo PC puedes abrir varias ventanas de incógnito con `…/#/phone` (cada una con su cuenta) y una pestaña normal `…/#/tv`. La TV y el celular usan almacenamiento de sesión separado, así que pueden convivir en el mismo navegador.
- Con 1 jugador la partida no inicia ("Necesitas al menos 2 jugadores para comenzar."); un 5.º jugador recibe "La sala está llena (4/4)".

## Cómo funciona
- **Celular → Realtime → TV**: los botones se envían como máscara de bits por *broadcast* (reenvío cada 250 ms mientras hay un botón presionado; la TV suelta botones si deja de recibir).
- La **TV ejecuta la lógica del juego** y, al terminar, llama a `finish_game`, que valida la sala, guarda `game_results` y actualiza `player_stats`.
- Salas, administrador, expulsiones, límite de 4 y estados se manejan con funciones SQL (`security definer`) y RLS; ningún cliente escribe directamente en esas tablas.
- Reconexión: latido cada 5 s del celular; la TV elimina jugadores sin señal por 40 s (fuera de partida) y transfiere el admin. Al volver la red el celular se reincorpora solo.

## Limitaciones reales
- El canal de broadcast es público (sin Realtime Authorization): quien conozca el ID interno de la sala (UUID) podría enviar controles falsos. El ID no se muestra; los resultados y estadísticas sí están protegidos por la TV propietaria de la sala.
- Los puntajes los calcula la TV (cliente). Un usuario malintencionado podría crear su propia sala y falsear sus estadísticas; para un juego entre amigos es aceptable.
- Durante una partida no se admiten jugadores nuevos, y un jugador sin señal sigue en la sala hasta que termina el juego.
- La latencia depende de internet (típicamente 50–200 ms); los juegos están diseñados para tolerarla, pero no son de reacción de milisegundos.
- Mantén las pantallas de los celulares encendidas durante la partida (se solicita *wake lock* donde el navegador lo permite). En iPhone es mejor usar el celular en horizontal.
- El Fire TV Stick básico puede ir justo de rendimiento con 4 jugadores en Pong/Nave; si hay lag, cierra otras apps.
- No se pudo compilar ni probar contra un Supabase real en el entorno de construcción (sin red). La lógica de los 12 juegos sí se simuló con 2, 3 y 4 jugadores sin errores; prueba el flujo completo tras configurar Supabase.
