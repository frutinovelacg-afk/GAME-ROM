export const W = 1280, H = 720;
export const COLORS = ['#ffd23f', '#ff5d73', '#3ddc97', '#c79bff'];
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const rnd = (a, b) => a + Math.random() * (b - a);
export const rint = (a, b) => Math.floor(rnd(a, b + 1));
export const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
export const shuffle = (arr) => { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
export const wrapPi = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };

export function txt(c, s, x, y, size = 32, color = '#fff', align = 'center', weight = '800') {
  c.font = `${weight} ${size}px "Trebuchet MS","Segoe UI",Arial,sans-serif`;
  c.fillStyle = color; c.textAlign = align; c.textBaseline = 'middle';
  c.fillText(String(s), x, y);
}
export function rrect(c, x, y, w, h, r) {
  c.beginPath();
  if (c.roundRect) c.roundRect(x, y, w, h, r);
  else c.rect(x, y, w, h);
}
export function bg(c, top = '#0a3fb8', bottom = '#041a45') {
  const g = c.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, top); g.addColorStop(1, bottom);
  c.fillStyle = g; c.fillRect(0, 0, W, H);
}
// Barra superior con nombre y puntos de cada jugador
export function hud(c, players, scoreOf, extra = '') {
  const w = 300;
  players.forEach((p, i) => {
    const x = 20 + i * (w + 10);
    c.fillStyle = 'rgba(0,0,0,.35)'; rrect(c, x, 12, w, 46, 14); c.fill();
    c.fillStyle = p.color; c.beginPath(); c.arc(x + 24, 35, 11, 0, 7); c.fill();
    txt(c, p.name.slice(0, 11), x + 44, 35, 22, '#fff', 'left');
    txt(c, scoreOf(p, i), x + w - 14, 35, 26, p.color, 'right', '900');
  });
  if (extra) txt(c, extra, W - 20, 82, 26, '#fff', 'right');
}
