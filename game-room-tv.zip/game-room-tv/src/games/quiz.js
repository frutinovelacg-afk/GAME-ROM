import { W, H, txt, bg, hud, rrect, shuffle, clamp } from './common.js';

// [pregunta, correcta, mala1, mala2, mala3]
const BANK = [
  ['¿Cuál es el planeta más grande del Sistema Solar?', 'Júpiter', 'Saturno', 'Neptuno', 'Tierra'],
  ['¿Cuántos jugadores hay en un equipo de fútbol en cancha?', '11', '9', '10', '12'],
  ['¿Cuál es la capital de Paraguay?', 'Asunción', 'Ciudad del Este', 'Encarnación', 'Luque'],
  ['¿Cuál es la capital de Brasil?', 'Brasilia', 'Río de Janeiro', 'São Paulo', 'Salvador'],
  ['¿Qué país ganó el Mundial de Fútbol de 2002?', 'Brasil', 'Alemania', 'Francia', 'Argentina'],
  ['¿Cuántos continentes hay?', '7', '5', '6', '8'],
  ['¿Cuál es el océano más grande?', 'Pacífico', 'Atlántico', 'Índico', 'Ártico'],
  ['¿Qué gas respiramos para vivir?', 'Oxígeno', 'Nitrógeno', 'Helio', 'Hidrógeno'],
  ['¿Cuál es el animal terrestre más rápido?', 'Guepardo', 'León', 'Caballo', 'Leopardo'],
  ['¿Cuántos días tiene un año bisiesto?', '366', '365', '364', '367'],
  ['¿Quién pintó la Mona Lisa?', 'Leonardo da Vinci', 'Picasso', 'Van Gogh', 'Miguel Ángel'],
  ['¿Cuál es el río más caudaloso del mundo?', 'Amazonas', 'Nilo', 'Paraná', 'Misisipi'],
  ['¿Cuál es el idioma más hablado en Brasil?', 'Portugués', 'Español', 'Inglés', 'Francés'],
  ['¿Qué idiomas oficiales tiene Paraguay?', 'Español y guaraní', 'Español y portugués', 'Solo español', 'Guaraní y quechua'],
  ['¿Cuántos lados tiene un hexágono?', '6', '5', '7', '8'],
  ['¿Cuánto es 9 × 7?', '63', '56', '72', '54'],
  ['¿Cuánto es 144 ÷ 12?', '12', '14', '11', '13'],
  ['¿Qué planeta es conocido como el planeta rojo?', 'Marte', 'Venus', 'Mercurio', 'Júpiter'],
  ['¿Cuál es el metal líquido a temperatura ambiente?', 'Mercurio', 'Hierro', 'Plomo', 'Cobre'],
  ['¿Qué país tiene forma de bota?', 'Italia', 'España', 'Grecia', 'Portugal'],
  ['¿Cuántos colores tiene el arcoíris?', '7', '6', '8', '5'],
  ['¿Cuál es el hueso más largo del cuerpo humano?', 'Fémur', 'Tibia', 'Húmero', 'Costilla'],
  ['¿Qué órgano bombea la sangre?', 'Corazón', 'Pulmón', 'Hígado', 'Riñón'],
  ['¿En qué continente está Egipto?', 'África', 'Asia', 'Europa', 'Oceanía'],
  ['¿Quién fue el primer hombre en pisar la Luna?', 'Neil Armstrong', 'Buzz Aldrin', 'Yuri Gagarin', 'Carl Sagan'],
  ['¿Cuál es el mamífero más grande del mundo?', 'Ballena azul', 'Elefante', 'Tiburón ballena', 'Jirafa'],
  ['¿Cuántos minutos tiene una hora y media?', '90', '80', '100', '120'],
  ['¿Qué animal es el símbolo de Brasil en la camiseta de la CBF?', 'Ninguno, es una estrella', 'Jaguar', 'Águila', 'León'],
  ['¿Qué selección ha ganado más Mundiales de fútbol masculino?', 'Brasil', 'Alemania', 'Italia', 'Argentina'],
  ['¿Cuál es el país más grande de Sudamérica?', 'Brasil', 'Argentina', 'Perú', 'Colombia'],
  ['¿Qué cataratas comparten Brasil, Argentina y Paraguay en su frontera?', 'Iguazú', 'Ángel', 'Niágara', 'Victoria'],
  ['¿Cuál es la moneda de Paraguay?', 'Guaraní', 'Peso', 'Real', 'Sol'],
  ['¿Cuál es la moneda de Brasil?', 'Real', 'Peso', 'Dólar', 'Cruzeiro'],
  ['¿Cuál es el desierto más grande del mundo (no polar)?', 'Sahara', 'Gobi', 'Atacama', 'Kalahari'],
  ['¿Cuántos huesos tiene un adulto aproximadamente?', '206', '150', '300', '412'],
  ['¿Qué instrumento tiene 88 teclas?', 'Piano', 'Órgano pequeño', 'Acordeón', 'Guitarra'],
  ['¿Cuál es el símbolo químico del agua?', 'H2O', 'CO2', 'O2', 'NaCl'],
  ['¿Qué estación sigue al verano?', 'Otoño', 'Invierno', 'Primavera', 'Verano'],
  ['¿Cuántas patas tiene una araña?', '8', '6', '10', '4'],
  ['¿Qué animal pone huevos y es mamífero?', 'Ornitorrinco', 'Murciélago', 'Delfín', 'Canguro'],
  ['¿Cuál es la montaña más alta del mundo?', 'Everest', 'K2', 'Aconcagua', 'Kilimanjaro'],
  ['¿Qué país inventó el sushi?', 'Japón', 'China', 'Corea', 'Tailandia'],
  ['¿Qué lenguaje se usa para dar estilo a páginas web?', 'CSS', 'SQL', 'Python', 'PHP'],
];
const N = 10, TQ = 15, TR = 3.2, LET = ['A', 'B', 'C', 'D'], COL = ['#2b8bff', '#ff5468', '#3ddc97', '#b07bff'];

export const quiz = {
  create({ players, inp, say }) {
    const qs = shuffle(BANK).slice(0, N).map((q) => {
      const opts = shuffle(q.slice(1)); return { q: q[0], opts, ok: opts.indexOf(q[1]) };
    });
    const score = players.map(() => 0);
    let qi = 0, phase = 'ask', t = 0, ans = {};
    const g = { over: false };
    const begin = () => { inp.take(); ans = {}; t = 0; phase = 'ask'; say(null, `Pregunta ${qi + 1}/${N}: elige tu respuesta`, 'q'); };
    begin();
    const reveal = () => {
      phase = 'reveal'; t = 0;
      players.forEach((p, i) => { const a = ans[p.id]; if (a && a.c === qs[qi].ok) score[i] += 500 + Math.round(500 * a.left / TQ); });
    };
    g.update = (dt) => {
      t += dt;
      if (phase === 'ask') {
        for (const a of inp.take()) if (players.some((p) => p.id === a.u) && !ans[a.u] && a.c >= 0 && a.c < 4) ans[a.u] = { c: a.c, left: Math.max(0, TQ - t) };
        if (players.every((p) => ans[p.id]) || t >= TQ) reveal();
      } else if (t >= TR) { qi++; if (qi >= N) g.over = true; else begin(); }
    };
    g.scores = () => players.map((p, i) => ({ user_id: p.id, score: score[i] }));
    g.draw = (c) => {
      bg(c, '#0a3fb8', '#041a45');
      const q = qs[Math.min(qi, N - 1)];
      c.fillStyle = '#fff'; rrect(c, 90, 100, W - 180, 190, 30); c.fill();
      txt(c, `Pregunta ${Math.min(qi + 1, N)}/${N}`, 130, 126, 22, '#1769ff', 'left');
      wrapTxt(c, q.q, W / 2, 200, W - 280, 52, '#041a45');
      q.opts.forEach((o, i) => {
        const x = 90 + (i % 2) * ((W - 190) / 2 + 10), y = 320 + Math.floor(i / 2) * 150, w = (W - 190) / 2, h = 128;
        const reveal = phase === 'reveal';
        c.globalAlpha = reveal && i !== q.ok ? 0.35 : 1;
        c.fillStyle = reveal && i === q.ok ? '#25c27d' : COL[i]; rrect(c, x, y, w, h, 26); c.fill();
        c.globalAlpha = 1;
        txt(c, LET[i], x + 52, y + h / 2, 64, '#fff', 'center', '900');
        txt(c, o, x + 100, y + h / 2, o.length > 22 ? 30 : 38, '#fff', 'left');
        players.forEach((p, k) => { if (reveal && ans[p.id] && ans[p.id].c === i) { c.fillStyle = p.color; c.beginPath(); c.arc(x + w - 28 - k * 30, y + 28, 12, 0, 7); c.fill(); } });
      });
      if (phase === 'ask') {
        const k = clamp(1 - t / TQ, 0, 1);
        c.fillStyle = 'rgba(255,255,255,.2)'; rrect(c, 90, 636, W - 180, 16, 8); c.fill();
        c.fillStyle = k < 0.3 ? '#ff5468' : '#ffd23f'; rrect(c, 90, 636, (W - 180) * k, 16, 8); c.fill();
        txt(c, `${players.filter((p) => ans[p.id]).length}/${players.length} respondieron`, W / 2, 676, 24, '#fff');
      } else txt(c, '¡Respuesta correcta resaltada!', W / 2, 656, 26, '#ffd23f');
      hud(c, players, (p, i) => score[i]);
    };
    return g;
  },
};

function wrapTxt(c, text, x, y, maxW, size, color) {
  c.font = `800 ${size}px "Trebuchet MS","Segoe UI",Arial,sans-serif`;
  const words = text.split(' '), lines = []; let line = '';
  for (const w of words) { const t = line ? line + ' ' + w : w; if (c.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t; }
  lines.push(line);
  const y0 = y - ((lines.length - 1) * (size + 6)) / 2;
  lines.forEach((l, i) => txt(c, l, x, y0 + i * (size + 6), size, color));
}
