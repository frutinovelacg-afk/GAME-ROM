import { W, H, txt, clamp, rnd, bg, hud, rrect } from './common.js';

const G = 2400, TOP = 96;

function make(mode) {
  return {
    create({ players, inp }) {
      const n = players.length, LH = (H - TOP - 8) / n, endless = mode === 'endless';
      const peak = Math.min(LH - 72, 125), JV = Math.sqrt(2 * G * peak);
      let t = 0, endTimer = null;
      const base = endless ? 380 : 340;
      const L = players.map((p, i) => ({
        p, top: TOP + i * LH, gy: TOP + i * LH + LH - 16, x: 220, yo: 0, vy: 0, obs: [], coins: [], dist: 0, gap: 0, spawned: 0,
        gapAt: rnd(500, 800), alive: true, died: 0, stun: 0, inv: 0, nCoins: 0, off: 0,
      }));
      const g = { over: false };
      g.update = (dt) => {
        t += dt;
        const spd = Math.min(endless ? 760 : 820, base + t * (endless ? 9 : 14));
        for (const l of L) {
          const id = l.p.id;
          if (l.alive) {
            if (l.stun <= 0) l.x = clamp(l.x + inp.dx(id) * 230 * dt, 110, 520);
            l.stun -= dt; l.inv -= dt;
            if (l.yo === 0 && l.stun <= 0 && (inp.held(id, 'u') || inp.held(id, 'a'))) l.vy = -JV;
            if (l.vy !== 0 || l.yo > 0) { l.vy += G * dt; l.yo = Math.max(0, l.yo - l.vy * dt); if (l.yo === 0) l.vy = 0; }
            if (l.yo === 0 && l.vy < 0) { l.yo = 0.001; }
            if (l.stun <= 0) l.dist += spd * dt / 100;
          }
          l.off = (l.off + spd * dt) % 80;
          l.gap += spd * dt;
          if (l.gap >= l.gapAt) {
            l.gap = 0; l.gapAt = spd * rnd(0.85, 1.5) + 40;
            const h = rnd(34, Math.min(LH * 0.45, 62)), w = rnd(26, 44);
            l.obs.push({ x: W + 40, w, h });
            if (endless && Math.random() < 0.7) l.coins.push({ x: W + 40 + rnd(180, 330), y: rnd(50, Math.max(60, peak + 8)) });
          }
          for (const o of l.obs) o.x -= spd * dt;
          for (const k of l.coins) k.x -= spd * dt;
          l.obs = l.obs.filter((o) => o.x > -80); l.coins = l.coins.filter((k) => k.x > -40);
          if (!l.alive) continue;
          const px0 = l.x - 15, px1 = l.x + 15, py0 = l.gy - l.yo - 44, py1 = l.gy - l.yo;
          for (const o of l.obs) {
            const ox0 = o.x + o.w * 0.15, ox1 = o.x + o.w * 0.85, oy0 = l.gy - o.h * 0.85;
            if (px1 > ox0 && px0 < ox1 && py1 > oy0 && l.inv <= 0) {
              if (endless) { l.stun = 0.7; l.inv = 1.3; l.x = Math.max(110, l.x - 60); }
              else { l.alive = false; l.died = t; }
            }
          }
          if (endless) l.coins = l.coins.filter((k) => {
            const hit = Math.abs(k.x - l.x) < 30 && Math.abs((l.gy - k.y) - (py0 + py1) / 2) < 44;
            if (hit) l.nCoins++; return !hit;
          });
        }
        if (endless) { if (t >= 60) g.over = true; }
        else {
          const alive = L.filter((l) => l.alive).length;
          if (alive === 0 || t > 120) g.over = true;
          else if (n >= 2 && alive <= 1) { endTimer = (endTimer ?? 0) + dt; if (endTimer > 1.5) g.over = true; }
        }
      };
      const sc = (l) => (endless ? Math.round(l.dist * 10) + l.nCoins * 50 : Math.round((l.alive ? t : l.died) * 20));
      g.scores = () => L.map((l) => ({ user_id: l.p.id, score: sc(l) }));
      g.draw = (c) => {
        bg(c, '#0a3fb8', '#041a45');
        L.forEach((l, i) => {
          c.fillStyle = i % 2 ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.13)'; c.fillRect(0, l.top, W, LH);
          c.fillStyle = '#e8f2ff'; c.fillRect(0, l.gy, W, 4);
          c.fillStyle = 'rgba(255,255,255,.35)'; for (let x = -l.off; x < W; x += 80) c.fillRect(x, l.gy + 8, 36, 4);
          txt(c, l.p.name.slice(0, 9), 12, l.top + 16, 20, l.p.color, 'left');
          for (const o of l.obs) { c.fillStyle = '#ff7a45'; c.beginPath(); c.moveTo(o.x, l.gy); c.lineTo(o.x + o.w / 2, l.gy - o.h); c.lineTo(o.x + o.w, l.gy); c.closePath(); c.fill(); }
          for (const k of l.coins) { c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(k.x, l.gy - k.y, 12, 0, 7); c.fill(); c.strokeStyle = '#b58f00'; c.lineWidth = 3; c.stroke(); }
          const blink = l.inv > 0 && Math.floor(t * 12) % 2 === 0;
          if (!blink) {
            c.fillStyle = l.alive ? l.p.color : '#7d8aa8'; rrect(c, l.x - 16, l.gy - l.yo - 44, 32, 44, 10); c.fill();
            c.fillStyle = '#041a45'; c.fillRect(l.x + 2, l.gy - l.yo - 34, 6, 8); c.fillRect(l.x + 10, l.gy - l.yo - 34, 6, 8);
            if (!l.alive) txt(c, '✕ FUERA', l.x + 90, l.gy - 30, 26, '#ff5468');
          }
        });
        hud(c, players, (p, i) => sc(L[i]), endless ? `${Math.max(0, Math.ceil(60 - t))}s` : `${Math.floor(t)}s`);
      };
      return g;
    },
  };
}
export const obstaculos = make('obst');
export const infinita = make('endless');
