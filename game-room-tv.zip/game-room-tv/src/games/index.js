import { racing } from './racing.js';
import { penales } from './penales.js';
import { soccer } from './soccer.js';
import { tiro } from './tiro.js';
import { quiz } from './quiz.js';
import { obstaculos, infinita } from './runner.js';
import { snake } from './snake.js';
import { monedas } from './monedas.js';
import { bloques } from './bloques.js';
import { nave } from './nave.js';
import { pong } from './pong.js';

export const impl = { carrera: racing, penales, partido: soccer, tiro, quiz, obstaculos, snake, infinita, monedas, bloques, nave, pong };
