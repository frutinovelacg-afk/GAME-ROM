import { W, H, txt, clamp, rnd, bg, hud, rrect } from './common.js';

const AX0 = 100, AX1 = 1180, AY0 = 100, AY1 = 690, PT = 16, LIVES = 5;
// lado: 0 izquierda, 1 derecha, 2 arriba, 3 abajo
const PL = [150, 150, 190, 190];

export const pong = {
  create({ players, inp }) {
    let t = 0, wait = 1.2, endT = null;
    const P = players.map((p, i) => ({ p, side: i, pos: i < 2 ? (AY0 + AY1) / 2 : (AX0 + AX1) / 2, lives: LIVES, hits: 0, died: 0 }));
    const ball = { x: 640, y: 395, vx: 0, vy: 0, sp: 430 };
    const serve = () => { const a = rnd(0, Math.PI * 2); ball.x = 640; ball.y = 395; ball.sp = 430; ball.vx = Math.cos(a) * ball.sp; ball.vy = Math.sin(a) * ball.sp; if (Math.abs(ball.vx) < 160 && Math.abs(ball.vy) < 160) { ball.vx = ball.sp; ball.vy = 100; } wait = 1; };
    const sideP = (s) => P.find((q) => q.side === s && q.lives > 0);
    const g = { over: false };
    g.update = (dt) => {
      t += dt;
      for (const q of P) {
        if (q.lives <= 0) continue;
        const id = q.p.id, d = ((inp.held(id, 'd') || inp.held(id, 'r')) ? 1 : 0) - ((inp.held(id, 'u') || inp.held(id, 'l')) ? 1 : 0);
        const lo = (q.side < 2 ? AY0 : AX0) + PL[q.side] / 2, hi = (q.side < 2 ? AY1 : AX1) - PL[q.side] / 2;
        q.pos = clamp(q.pos + d * 620 * dt, lo, hi);
      }
      if (wait > 0) { wait -= dt; if (wait <= 0 && ball.vx === 0 && ball.vy === 0) serve(); if (!(ball.vx || ball.vy)) serve(); return; }
      ball.x += ball.vx * dt; ball.y += ball.vy * dt;
      const R = 12;
      const hit = (q, rel) => { q.hits++; ball.sp = Math.min(900, ball.sp + 25); return rel; };
      const out = (s) => { const q = P.find((z) => z.side === s); if (q && q.lives > 0) { q.lives--; if (q.lives <= 0) q.died = t; } serve(); };
      const bounceSide = (s, pen) => {
        const q = sideP(s);
        const along = s < 2 ? ball.y : ball.x;
        if (q && pen) { // dentro de la zona del paddle
          if (Math.abs(along - q.pos) <= PL[s] / 2 + R) {
            const rel = clamp((along - q.pos) / (PL[s] / 2), -1, 1); hit(q);
            const a = rel * 0.9, dir = s === 0 || s === 2 ? 1 : -1;
            if (s < 2) { ball.vx = Math.cos(a) * ball.sp * dir; ball.vy = Math.sin(a) * ball.sp; } else { ball.vy = Math.cos(a) * ball.sp * dir; ball.vx = Math.sin(a) * ball.sp; }
            return true;
          }
          return false;
        }
        return null;
      };
      // izquierda
      if (ball.vx < 0 && ball.x - R <= AX0 + PT) {
        const q = sideP(0);
        if (q) { if (bounceSide(0, true)) ball.x = AX0 + PT + R; else if (ball.x < AX0 - 20) out(0); }
        else if (ball.x - R <= AX0) { ball.x = AX0 + R; ball.vx = Math.abs(ball.vx); }
      }
      if (ball.vx > 0 && ball.x + R >= AX1 - PT) {
        const q = sideP(1);
        if (q) { if (bounceSide(1, true)) ball.x = AX1 - PT - R; else if (ball.x > AX1 + 20) out(1); }
        else if (ball.x + R >= AX1) { ball.x = AX1 - R; ball.vx = -Math.abs(ball.vx); }
      }
      if (ball.vy < 0 && ball.y - R <= AY0 + PT) {
        const q = sideP(2);
        if (q) { if (bounceSide(2, true)) ball.y = AY0 + PT + R; else if (ball.y < AY0 - 20) out(2); }
        else if (ball.y - R <= AY0) { ball.y = AY0 + R; ball.vy = Math.abs(ball.vy); }
      }
      if (ball.vy > 0 && ball.y + R >= AY1 - PT) {
        const q = sideP(3);
        if (q) { if (bounceSide(3, true)) ball.y = AY1 - PT - R; else if (ball.y > AY1 + 20) out(3); }
        else if (ball.y + R >= AY1) { ball.y = AY1 - R; ball.vy = -Math.abs(ball.vy); }
      }
      const alive = P.filter((q) => q.lives > 0).length;
      if (alive === 0 || t > 180) g.over = true;
      else if (P.length >= 2 && alive <= 1) { endT = (endT ?? 0) + dt; if (endT > 1.2) g.over = true; }
    };
    const sc = (q) => q.lives * 150 + q.hits * 20 + (q.lives > 0 && P.length >= 2 ? 500 : 0) + Math.floor(q.lives > 0 ? 0 : q.died);
    g.scores = () => P.map((q) => ({ user_id: q.p.id, score: sc(q) }));
    g.draw = (c) => {
      bg(c, '#06307f', '#041a45');
      c.fillStyle = 'rgba(255,255,255,.08)'; c.fillRect(AX0, AY0, AX1 - AX0, AY1 - AY0);
      c.strokeStyle = '#fff'; c.lineWidth = 5; c.strokeRect(AX0, AY0, AX1 - AX0, AY1 - AY0);
      c.setLineDash([16, 16]); c.strokeStyle = 'rgba(255,255,255,.3)'; c.beginPath(); c.moveTo(640, AY0); c.lineTo(640, AY1); c.moveTo(AX0, 395); c.lineTo(AX1, 395); c.stroke(); c.setLineDash([]);
      for (const q of P) {
        if (q.lives <= 0) continue;
        c.fillStyle = q.p.color; const L = PL[q.side];
        if (q.side === 0) rrect(c, AX0, q.pos - L / 2, PT, L, 8);
        else if (q.side === 1) rrect(c, AX1 - PT, q.pos - L / 2, PT, L, 8);
        else if (q.side === 2) rrect(c, q.pos - L / 2, AY0, L, PT, 8);
        else rrect(c, q.pos - L / 2, AY1 - PT, L, PT, 8);
        c.fill();
        const lx = q.side === 0 ? AX0 - 6 : q.side === 1 ? AX1 + 6 : q.pos, ly = q.side === 2 ? AY0 - 14 : q.side === 3 ? AY1 + 16 : q.pos;
        txt(c, `${q.p.name.slice(0, 6)} ${'♥'.repeat(q.lives)}`, clamp(lx, 90, W - 90), ly, 20, q.p.color, q.side === 0 ? 'right' : q.side === 1 ? 'left' : 'center');
      }
      c.fillStyle = '#fff'; c.beginPath(); c.arc(ball.x, ball.y, 12, 0, 7); c.fill();
      hud(c, players, (p, i) => sc(P[i]));
    };
    return g;
  },
};
