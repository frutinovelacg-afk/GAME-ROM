import { W, H, txt, rrect, bg } from './common.js';
import { impl } from './index.js';

const RULES_T = 7;

// Ejecuta un juego en el canvas de la TV: reglas -> cuenta atrás -> juego -> fin
export function playGame({ canvas, meta, players, inp, say, onEnd }) {
  const c = canvas.getContext('2d');
  const game = impl[meta.id].create({ players, inp, say, W, H });
  let phase = 'rules', t = 0, raf = 0, last = performance.now(), stopped = false, ended = false;
  say(null, `${meta.emoji} ${meta.name}: mira la TV`, 'i');

  function drawRules() {
    bg(c);
    txt(c, `${meta.emoji} ${meta.name}`, W / 2, 150, 84);
    c.fillStyle = '#fff'; rrect(c, 140, 230, W - 280, 280, 32); c.fill();
    wrap(c, meta.rules, W / 2, 330, W - 380, 40, '#041a45');
    txt(c, `Comienza en ${Math.max(1, Math.ceil(RULES_T - t))}`, W / 2, 600, 40, '#ffd23f');
    players.forEach((p, i) => txt(c, p.name, W / 2 - ((players.length - 1) * 150) / 2 + i * 150 * 1 + 0, 660, 26, p.color));
  }
  function frame(now) {
    if (stopped) return;
    const dt = Math.min(0.05, (now - last) / 1000); last = now; t += dt;
    inp.tick(now);
    if (phase === 'rules') { drawRules(); if (t >= RULES_T) { phase = 'count'; t = 0; } }
    else if (phase === 'count') {
      game.draw(c);
      c.fillStyle = 'rgba(4,26,69,.55)'; c.fillRect(0, 0, W, H);
      txt(c, Math.max(1, Math.ceil(3 - t)), W / 2, H / 2, 260, '#fff', 'center', '900');
      if (t >= 3) { phase = 'play'; t = 0; }
    } else if (phase === 'play') {
      game.update(dt); game.draw(c);
      if (game.over) { phase = 'end'; t = 0; }
    } else {
      game.draw(c);
      c.fillStyle = 'rgba(4,26,69,.6)'; c.fillRect(0, 0, W, H);
      txt(c, '¡FIN!', W / 2, H / 2, 200, '#ffd23f', 'center', '900');
      if (t > 2.5 && !ended) { ended = true; onEnd(game.scores()); }
    }
    raf = requestAnimationFrame(frame);
  }
  raf = requestAnimationFrame(frame);
  return () => { stopped = true; cancelAnimationFrame(raf); };
}

function wrap(c, text, x, y, maxW, lh, color) {
  c.font = '800 34px "Trebuchet MS","Segoe UI",Arial,sans-serif';
  const words = text.split(' '); let line = '', yy = y;
  for (const w of words) {
    const test = line ? line + ' ' + w : w;
    if (c.measureText(test).width > maxW && line) { txt(c, line, x, yy, 34, color); line = w; yy += lh; } else line = test;
  }
  txt(c, line, x, yy, 34, color);
}
