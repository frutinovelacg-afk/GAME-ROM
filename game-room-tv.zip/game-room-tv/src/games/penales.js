import { W, H, txt, clamp, rnd, rint, hud, rrect } from './common.js';

const GX = 640, GW = 300, GTOP = 190, GBOT = 410, ROUNDS = 3;
const tx = (x) => GX + x * GW, ty = (y) => GBOT - y * (GBOT - GTOP);

export const penales = {
  create({ players, inp, say }) {
    const goals = players.map(() => 0);
    let round = 1, queue = players.map((_, i) => i), qi = 0;
    let phase = 'aim', pt = 0, aim = { x: 0, y: 0.5 }, pw = 0, charging = false, msg = '', msgCol = '#fff';
    let shot = null, keeper = { x: 0, y: 0.4 };
    const g = { over: false };

    function announce() {
      const p = players[queue[qi]];
      say(null, `Turno de ${p.name}`, 'i');
      say(p.id, '🎯 ¡TU TURNO! Apunta, mantén 🥅 y suelta', 'i');
    }
    announce();

    function shoot() {
      const s = queue[qi], ax = aim.x, ay = aim.y, p = pw || 0.6;
      let kx = [-0.66, 0, 0.66][rint(0, 2)], ky = Math.random() < 0.5 ? 0.3 : 0.75;
      if (Math.random() < 0.28) { kx = clamp(ax, -0.7, 0.7); ky = ay > 0.55 ? 0.75 : 0.3; }
      let res = 'gol';
      if (Math.abs(ax) > 1 || ay > 1) res = 'fuera';
      else if (p > 0.97 && ay > 0.75) res = 'alto';
      else {
        const k = p < 0.35 ? 1.4 : 1;
        if (((ax - kx) / (0.5 * k)) ** 2 + ((ay - ky) / (0.55 * k)) ** 2 < 1) res = 'atajado';
      }
      shot = { s, res, ax, ay, kx, ky };
      if (res === 'gol') goals[s]++;
      msg = res === 'gol' ? '¡GOOOL!' : res === 'atajado' ? '¡ATAJADO!' : '¡AFUERA!';
      msgCol = res === 'gol' ? '#3ddc97' : '#ff5d73';
      phase = 'fly'; pt = 0;
    }
    function nextTurn() {
      qi++;
      if (qi >= queue.length) {
        if (round >= ROUNDS) {
          const mx = Math.max(...goals), tied = goals.map((v, i) => (v === mx ? i : -1)).filter((i) => i >= 0);
          if (tied.length === 1 || round >= 8) { g.over = true; return; }
          queue = tied;
        }
        round++; qi = 0;
      }
      aim = { x: 0, y: 0.5 }; pw = 0; charging = false; shot = null; phase = 'aim'; pt = 0; msg = '';
      announce();
    }

    g.update = (dt) => {
      pt += dt;
      const p = players[queue[qi]];
      if (phase === 'aim') {
        aim.x = clamp(aim.x + inp.dx(p.id) * 0.9 * dt, -1.2, 1.2);
        aim.y = clamp(aim.y - inp.dy(p.id) * 0.8 * dt, 0.03, 1.2);
        if (inp.held(p.id, 'a')) { charging = true; pw = Math.min(1, pw + dt / 1.2); }
        if ((charging && inp.released(p.id, 'a') && pw > 0.05) || pt > 14) shoot();
      } else if (phase === 'fly') { if (pt > 0.8) { phase = 'result'; pt = 0; } }
      else if (pt > 1.6) nextTurn();
    };
    g.scores = () => players.map((p, i) => ({ user_id: p.id, score: goals[i] * 100 }));
    g.draw = (c) => {
      const sky = c.createLinearGradient(0, 0, 0, 430); sky.addColorStop(0, '#0a3fb8'); sky.addColorStop(1, '#2f7bff');
      c.fillStyle = sky; c.fillRect(0, 0, W, 430);
      const gr = c.createLinearGradient(0, 430, 0, H); gr.addColorStop(0, '#1fa86a'); gr.addColorStop(1, '#127a48');
      c.fillStyle = gr; c.fillRect(0, 430, W, H - 430);
      // arco y red
      c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 2;
      for (let x = GX - GW; x <= GX + GW; x += 30) { c.beginPath(); c.moveTo(x, GTOP); c.lineTo(x, GBOT); c.stroke(); }
      for (let y = GTOP; y <= GBOT; y += 30) { c.beginPath(); c.moveTo(GX - GW, y); c.lineTo(GX + GW, y); c.stroke(); }
      c.strokeStyle = '#fff'; c.lineWidth = 12; c.beginPath(); c.moveTo(GX - GW, GBOT); c.lineTo(GX - GW, GTOP); c.lineTo(GX + GW, GTOP); c.lineTo(GX + GW, GBOT); c.stroke();
      // portero
      let kx = 0, ky = 0.4;
      if (shot) { const e = clamp((pt - (phase === 'fly' ? 0.1 : 0.8)) / 0.35, 0, 1); const k = phase === 'fly' ? e : 1; kx = shot.kx * k; ky = 0.4 + (shot.ky - 0.4) * k; }
      const kxp = tx(kx * 0.9), kyp = ty(ky) + 20;
      c.fillStyle = '#ffd23f'; rrect(c, kxp - 22, kyp - 50, 44, 80, 14); c.fill();
      c.strokeStyle = '#ffd23f'; c.lineWidth = 12; c.beginPath(); c.moveTo(kxp - 22, kyp - 30); c.lineTo(kxp - 60, kyp - 55 - ky * 20); c.moveTo(kxp + 22, kyp - 30); c.lineTo(kxp + 60, kyp - 55 - ky * 20); c.stroke();
      c.fillStyle = '#f2c9a0'; c.beginPath(); c.arc(kxp, kyp - 66, 15, 0, 7); c.fill();
      // pelota
      let bx = GX, by = 600, bs = 1;
      if (phase === 'aim' || !shot) { bx = GX; by = 600; }
      else { const e = clamp(pt / 0.5, 0, 1); bx = GX + (tx(shot.ax) - GX) * e; by = 600 + (ty(shot.ay) - 600) * e; bs = 1 - 0.5 * e; if (phase !== 'fly') { bx = tx(shot.ax); by = ty(shot.ay); bs = 0.5; } }
      c.fillStyle = '#fff'; c.beginPath(); c.arc(bx, by, 24 * bs, 0, 7); c.fill();
      c.strokeStyle = '#041a45'; c.lineWidth = 3; c.stroke();
      if (phase === 'aim') {
        const p = players[queue[qi]];
        c.strokeStyle = p.color; c.lineWidth = 6; c.beginPath(); c.arc(tx(aim.x), ty(aim.y), 26, 0, 7); c.moveTo(tx(aim.x) - 38, ty(aim.y)); c.lineTo(tx(aim.x) + 38, ty(aim.y)); c.moveTo(tx(aim.x), ty(aim.y) - 38); c.lineTo(tx(aim.x), ty(aim.y) + 38); c.stroke();
        c.fillStyle = 'rgba(0,0,0,.4)'; rrect(c, 440, 668, 400, 26, 13); c.fill();
        c.fillStyle = pw > 0.9 ? '#ff5d73' : '#ffd23f'; rrect(c, 440, 668, Math.max(0, 400 * pw), 26, 13); c.fill();
        txt(c, `Tira: ${p.name}`, W / 2, 128, 44, p.color);
        txt(c, `${Math.max(0, Math.ceil(14 - pt))}`, W - 40, 128, 36, '#fff', 'right');
      }
      if (msg) txt(c, msg, W / 2, 300, 120, msgCol, 'center', '900');
      hud(c, players, (p, i) => goals[i] * 100, `Ronda ${Math.min(round, ROUNDS)}/${ROUNDS}${round > ROUNDS ? ' · Muerte súbita' : ''}`);
    };
    return g;
  },
};
