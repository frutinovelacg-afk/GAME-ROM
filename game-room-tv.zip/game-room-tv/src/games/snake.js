import { W, H, txt, bg, rrect, rint } from './common.js';

const CS = 32, COLS = 40, ROWS = 21, OY = 48;
const START = [[5, 5, 1, 0], [34, 15, -1, 0], [34, 5, -1, 0], [5, 15, 1, 0]];
const DIRS = { l: [-1, 0], r: [1, 0], u: [0, -1], d: [0, 1] };

export const snake = {
  create({ players, inp }) {
    let t = 0, acc = 0, endT = null;
    const S = players.map((p, i) => {
      const [x, y, dx, dy] = START[i];
      return { p, body: [[x, y], [x - dx, y - dy], [x - 2 * dx, y - 2 * dy], [x - 3 * dx, y - 3 * dy]], dir: [dx, dy], next: [dx, dy], alive: true, foods: 0, died: 0 };
    });
    const foods = [];
    const free = () => {
      for (let k = 0; k < 200; k++) {
        const x = rint(0, COLS - 1), y = rint(0, ROWS - 1);
        if (!S.some((s) => s.body.some((b) => b[0] === x && b[1] === y)) && !foods.some((f) => f[0] === x && f[1] === y)) return [x, y];
      }
      return [0, 0];
    };
    for (let i = 0; i < 5; i++) foods.push(free());
    const total = () => S.reduce((a, s) => a + s.foods, 0);
    const g = { over: false };
    g.update = (dt) => {
      t += dt;
      for (const s of S) if (s.alive) for (const k in DIRS) if (inp.held(s.p.id, k)) { const d = DIRS[k]; if (d[0] !== -s.dir[0] || d[1] !== -s.dir[1]) s.next = d; }
      acc += dt;
      const step = Math.max(0.07, 0.12 - total() * 0.0008);
      if (acc >= step) {
        acc -= step;
        const heads = S.map((s) => (s.alive ? (s.dir = s.next, [s.body[0][0] + s.dir[0], s.body[0][1] + s.dir[1]]) : null));
        const willEat = heads.map((h) => (h ? foods.findIndex((f) => f[0] === h[0] && f[1] === h[1]) >= 0 : false));
        const dead = S.map((s, i) => {
          const h = heads[i]; if (!h) return false;
          if (h[0] < 0 || h[1] < 0 || h[0] >= COLS || h[1] >= ROWS) return true;
          for (let j = 0; j < S.length; j++) {
            if (!S[j].alive) continue;
            const body = S[j].body, len = willEat[j] ? body.length : body.length - 1;
            for (let k = 0; k < len; k++) if (body[k][0] === h[0] && body[k][1] === h[1]) return true;
            if (j !== i && heads[j] && heads[j][0] === h[0] && heads[j][1] === h[1]) return true;
          }
          return false;
        });
        S.forEach((s, i) => {
          if (!s.alive) return;
          if (dead[i]) { s.alive = false; s.died = t; s.body = []; return; }
          s.body.unshift(heads[i]);
          if (willEat[i]) {
            const fi = foods.findIndex((f) => f[0] === heads[i][0] && f[1] === heads[i][1]);
            foods.splice(fi, 1); s.foods++; foods.push(free());
          } else s.body.pop();
        });
      }
      const alive = S.filter((s) => s.alive).length;
      if (alive === 0 || t > 150) g.over = true;
      else if (S.length >= 2 && alive <= 1) { endT = (endT ?? 0) + dt; if (endT > 1.2) g.over = true; }
    };
    const sc = (s) => s.foods * 100 + Math.round((s.alive ? t : s.died) * 2) + (s.alive && S.length >= 2 ? 300 : 0);
    g.scores = () => S.map((s) => ({ user_id: s.p.id, score: sc(s) }));
    g.draw = (c) => {
      bg(c, '#06307f', '#041a45');
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) { c.fillStyle = (x + y) % 2 ? 'rgba(255,255,255,.05)' : 'rgba(255,255,255,.09)'; c.fillRect(x * CS, OY + y * CS, CS, CS); }
      c.fillStyle = '#ff5468'; for (const f of foods) { c.beginPath(); c.arc(f[0] * CS + 16, OY + f[1] * CS + 16, 11, 0, 7); c.fill(); }
      for (const s of S) {
        s.body.forEach((b, i) => { c.fillStyle = s.p.color; c.globalAlpha = i ? 0.85 : 1; rrect(c, b[0] * CS + 2, OY + b[1] * CS + 2, CS - 4, CS - 4, 9); c.fill(); });
        c.globalAlpha = 1;
        if (s.body[0]) { c.fillStyle = '#041a45'; c.beginPath(); c.arc(s.body[0][0] * CS + 16 + s.dir[0] * 6 - s.dir[1] * 6, OY + s.body[0][1] * CS + 16 + s.dir[1] * 6 + s.dir[0] * 6, 3.5, 0, 7); c.arc(s.body[0][0] * CS + 16 + s.dir[0] * 6 + s.dir[1] * 6, OY + s.body[0][1] * CS + 16 + s.dir[1] * 6 - s.dir[0] * 6, 3.5, 0, 7); c.fill(); }
      }
      c.fillStyle = 'rgba(4,26,69,.8)'; c.fillRect(0, 0, W, OY);
      const w = 300;
      S.forEach((s, i) => { const x = 20 + i * (w + 10); c.fillStyle = s.p.color; c.beginPath(); c.arc(x + 14, 24, 10, 0, 7); c.fill(); txt(c, `${s.p.name.slice(0, 9)}${s.alive ? '' : ' ✕'}`, x + 32, 24, 22, s.alive ? '#fff' : '#8b97b3', 'left'); txt(c, sc(s), x + w - 8, 24, 26, s.p.color, 'right', '900'); });
    };
    return g;
  },
};
