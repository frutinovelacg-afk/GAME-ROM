import { W, H, txt, clamp, rnd, bg, hud, dist } from './common.js';

const DUR = 90;

export const nave = {
  create({ players, inp }) {
    let t = 0, spawn = 1;
    const stars = Array.from({ length: 70 }, () => ({ x: rnd(0, W), y: rnd(0, H), s: rnd(40, 160), r: rnd(1, 2.6) }));
    const S = players.map((p, i) => ({ p, x: 200 + i * 290, y: H - 80, lives: 3, inv: 0, cd: 0, score: 0, x0: 200 + i * 290 }));
    const bullets = [], enemies = [], eb = [];
    const g = { over: false };
    g.update = (dt) => {
      t += dt; if (t >= DUR) { g.over = true; return; }
      for (const s of stars) { s.y += s.s * dt; if (s.y > H) { s.y = 0; s.x = rnd(0, W); } }
      spawn -= dt;
      if (spawn <= 0) {
        spawn = Math.max(0.45, 1.2 - t * 0.008);
        if (Math.random() < 0.62) enemies.push({ k: 'ship', x: rnd(80, W - 80), y: -30, x0: 0, hp: 1, r: 24, vy: 90 + t, fire: rnd(0.8, 2) });
        else enemies.push({ k: 'rock', x: rnd(60, W - 60), y: -40, hp: 2, r: 32, vy: rnd(150, 250) + t, vx: rnd(-60, 60) });
        enemies.forEach((e) => { if (e.k === 'ship' && !e.x0) e.x0 = e.x; });
      }
      for (const e of enemies) {
        e.y += e.vy * dt;
        if (e.k === 'ship') { e.x = e.x0 + Math.sin(e.y / 60) * 70; e.fire -= dt; if (e.fire <= 0 && e.y < H * 0.6) { eb.push({ x: e.x, y: e.y + 20 }); e.fire = rnd(1.4, 2.4); } }
        else e.x += e.vx * dt;
      }
      for (let i = enemies.length - 1; i >= 0; i--) if (enemies[i].y > H + 60) enemies.splice(i, 1);
      for (const b of eb) b.y += 330 * dt;
      for (let i = eb.length - 1; i >= 0; i--) if (eb[i].y > H + 20) eb.splice(i, 1);
      for (const s of S) {
        if (s.lives <= 0) continue;
        s.x = clamp(s.x + inp.dx(s.p.id) * 340 * dt, 24, W - 24); s.y = clamp(s.y + inp.dy(s.p.id) * 340 * dt, 130, H - 30);
        s.cd -= dt; s.inv -= dt;
        if (inp.held(s.p.id, 'a') && s.cd <= 0) { bullets.push({ x: s.x, y: s.y - 24, o: s }); s.cd = 0.22; }
      }
      for (const b of bullets) b.y -= 820 * dt;
      for (let i = bullets.length - 1; i >= 0; i--) {
        const b = bullets[i]; let used = false;
        if (b.y < -20) { bullets.splice(i, 1); continue; }
        for (let j = enemies.length - 1; j >= 0 && !used; j--) {
          const e = enemies[j];
          if (dist(b.x, b.y, e.x, e.y) < e.r + 6) {
            used = true; e.hp--;
            if (e.hp <= 0) { b.o.score += e.k === 'ship' ? 100 : 50; enemies.splice(j, 1); } else b.o.score += 25;
          }
        }
        if (used) bullets.splice(i, 1);
      }
      for (const s of S) {
        if (s.lives <= 0 || s.inv > 0) continue;
        let hit = false;
        for (let j = enemies.length - 1; j >= 0; j--) if (dist(s.x, s.y, enemies[j].x, enemies[j].y) < enemies[j].r + 16) { enemies.splice(j, 1); hit = true; break; }
        if (!hit) for (let j = eb.length - 1; j >= 0; j--) if (dist(s.x, s.y, eb[j].x, eb[j].y) < 20) { eb.splice(j, 1); hit = true; break; }
        if (hit) { s.lives--; s.inv = 2; s.x = s.x0; s.y = H - 80; }
      }
      if (S.every((s) => s.lives <= 0)) g.over = true;
    };
    g.scores = () => S.map((s) => ({ user_id: s.p.id, score: s.score }));
    g.draw = (c) => {
      bg(c, '#020d26', '#0a2a6e');
      c.fillStyle = '#fff'; for (const s of stars) { c.globalAlpha = 0.4 + s.r / 4; c.fillRect(s.x, s.y, s.r, s.r); } c.globalAlpha = 1;
      for (const e of enemies) {
        if (e.k === 'rock') { c.fillStyle = '#8d6e63'; c.beginPath(); c.arc(e.x, e.y, e.r, 0, 7); c.fill(); c.fillStyle = '#6d4c41'; c.beginPath(); c.arc(e.x - 8, e.y - 6, 9, 0, 7); c.fill(); }
        else { c.fillStyle = '#b07bff'; c.beginPath(); c.moveTo(e.x, e.y + 24); c.lineTo(e.x - 26, e.y - 16); c.lineTo(e.x + 26, e.y - 16); c.closePath(); c.fill(); c.fillStyle = '#fff'; c.fillRect(e.x - 5, e.y - 10, 10, 10); }
      }
      c.fillStyle = '#ff5468'; for (const b of eb) { c.beginPath(); c.arc(b.x, b.y, 7, 0, 7); c.fill(); }
      for (const b of bullets) { c.fillStyle = b.o.p.color; c.fillRect(b.x - 3, b.y - 12, 6, 22); }
      for (const s of S) {
        if (s.lives <= 0) continue;
        if (s.inv > 0 && Math.floor(t * 12) % 2) continue;
        c.fillStyle = s.p.color; c.beginPath(); c.moveTo(s.x, s.y - 26); c.lineTo(s.x - 22, s.y + 18); c.lineTo(s.x, s.y + 8); c.lineTo(s.x + 22, s.y + 18); c.closePath(); c.fill();
        txt(c, s.p.name.slice(0, 8), s.x, s.y + 38, 18, '#fff');
      }
      hud(c, players, (p, i) => `${'♥'.repeat(Math.max(0, S[i].lives))} ${S[i].score}`, `${Math.max(0, Math.ceil(DUR - t))}s`);
    };
    return g;
  },
};
