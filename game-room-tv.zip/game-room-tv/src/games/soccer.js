import { W, H, txt, clamp, bg, rrect, dist } from './common.js';

const X0 = 60, Y0 = 80, X1 = 1220, Y1 = 680, CY = (Y0 + Y1) / 2, GH = 100, TEAM = ['#2b8bff', '#ff5468'], DUR = 90;

export const soccer = {
  create({ players, inp }) {
    let time = DUR, pause = 0, banner = '';
    const pls = players.map((p, i) => ({ p, team: i % 2, x: 0, y: 0, vx: 0, vy: 0, cd: 0, goals: 0, k: 0 }));
    const ball = { x: 640, y: CY, vx: 0, vy: 0, last: -1 };
    const teamGoals = [0, 0];
    const reset = () => {
      const c = [0, 0];
      pls.forEach((q) => { const n = c[q.team]++; q.x = q.team ? 880 + n * 100 : 400 - n * 100; q.y = CY + (n % 2 ? 110 : -110); q.vx = q.vy = 0; });
      Object.assign(ball, { x: 640, y: CY, vx: 0, vy: 0 });
    };
    reset();
    const g = { over: false };
    g.update = (dt) => {
      if (pause > 0) { pause -= dt; if (pause <= 0) { banner = ''; reset(); } return; }
      time -= dt; if (time <= 0) { g.over = true; return; }
      for (const q of pls) {
        const id = q.p.id; let dx = inp.dx(id), dy = inp.dy(id); const l = Math.hypot(dx, dy) || 1;
        q.vx += ((dx / l) * 280 - q.vx) * Math.min(1, dt * 10); q.vy += ((dy / l) * 280 - q.vy) * Math.min(1, dt * 10);
        q.x = clamp(q.x + q.vx * dt, X0 + 26, X1 - 26); q.y = clamp(q.y + q.vy * dt, Y0 + 26, Y1 - 26);
        q.cd -= dt;
        const d = dist(q.x, q.y, ball.x, ball.y);
        if (d < 26 + 14) { // contacto
          const nx = (ball.x - q.x) / (d || 1), ny = (ball.y - q.y) / (d || 1);
          ball.x = q.x + nx * 41; ball.y = q.y + ny * 41;
          const vn = (ball.vx - q.vx) * nx + (ball.vy - q.vy) * ny;
          if (vn < 0) { ball.vx -= 1.6 * vn * nx; ball.vy -= 1.6 * vn * ny; }
          ball.last = pls.indexOf(q);
        }
        const kick = inp.pressed(id, 'a') ? 760 : inp.pressed(id, 'b') ? 470 : 0;
        if (kick && q.cd <= 0 && d < 26 + 14 + 24) {
          let nx = (ball.x - q.x) / (d || 1), ny = (ball.y - q.y) / (d || 1);
          if (kick === 470) { // pase hacia compañero más cercano
            const mate = pls.filter((o) => o !== q && o.team === q.team).sort((a, b) => dist(a.x, a.y, ball.x, ball.y) - dist(b.x, b.y, ball.x, ball.y))[0];
            if (mate) { const md = dist(mate.x, mate.y, ball.x, ball.y) || 1; nx = (mate.x - ball.x) / md; ny = (mate.y - ball.y) / md; }
          }
          ball.vx = nx * kick + q.vx * 0.3; ball.vy = ny * kick + q.vy * 0.3; q.cd = 0.25; ball.last = pls.indexOf(q);
        }
      }
      for (let i = 0; i < pls.length; i++) for (let j = i + 1; j < pls.length; j++) {
        const a = pls[i], b = pls[j], d = dist(a.x, a.y, b.x, b.y);
        if (d < 52 && d > 0) { const k = (52 - d) / 2, nx = (b.x - a.x) / d, ny = (b.y - a.y) / d; a.x -= nx * k; a.y -= ny * k; b.x += nx * k; b.y += ny * k; }
      }
      const f = Math.pow(0.55, dt); ball.vx *= f; ball.vy *= f;
      ball.x += ball.vx * dt; ball.y += ball.vy * dt;
      if (ball.y < Y0 + 14) { ball.y = Y0 + 14; ball.vy = Math.abs(ball.vy) * 0.8; }
      if (ball.y > Y1 - 14) { ball.y = Y1 - 14; ball.vy = -Math.abs(ball.vy) * 0.8; }
      const inMouth = Math.abs(ball.y - CY) < GH;
      if (ball.x < X0 + 14 && !inMouth) { ball.x = X0 + 14; ball.vx = Math.abs(ball.vx) * 0.8; }
      if (ball.x > X1 - 14 && !inMouth) { ball.x = X1 - 14; ball.vx = -Math.abs(ball.vx) * 0.8; }
      if (ball.x < X0 - 10 || ball.x > X1 + 10) {
        const t = ball.x < X0 ? 1 : 0; teamGoals[t]++;
        const s = ball.last >= 0 ? pls[ball.last] : null; if (s && s.team === t) s.goals++;
        banner = '¡GOOOL!'; pause = 2;
      }
    };
    const scoreOf = (q) => { const win = teamGoals[q.team] > teamGoals[1 - q.team]; return teamGoals[q.team] * 200 + q.goals * 100 + (win ? 300 : 0); };
    g.scores = () => pls.map((q) => ({ user_id: q.p.id, score: scoreOf(q) }));
    g.draw = (c) => {
      bg(c, '#0a3fb8', '#041a45');
      for (let i = 0; i < 10; i++) { c.fillStyle = i % 2 ? '#1c9a60' : '#21a96a'; c.fillRect(X0 + i * 116, Y0, 116, Y1 - Y0); }
      c.strokeStyle = '#fff'; c.lineWidth = 5; c.strokeRect(X0, Y0, X1 - X0, Y1 - Y0);
      c.beginPath(); c.moveTo(640, Y0); c.lineTo(640, Y1); c.stroke(); c.beginPath(); c.arc(640, CY, 90, 0, 7); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.85)'; c.fillRect(X0 - 24, CY - GH, 24, GH * 2); c.fillRect(X1, CY - GH, 24, GH * 2);
      for (const q of pls) {
        c.fillStyle = TEAM[q.team]; c.beginPath(); c.arc(q.x, q.y, 26, 0, 7); c.fill();
        c.lineWidth = 5; c.strokeStyle = q.p.color; c.stroke();
        txt(c, q.p.name.slice(0, 8), q.x, q.y - 42, 20, '#fff');
      }
      c.fillStyle = '#fff'; c.beginPath(); c.arc(ball.x, ball.y, 14, 0, 7); c.fill(); c.strokeStyle = '#041a45'; c.lineWidth = 3; c.stroke();
      c.fillStyle = 'rgba(0,0,0,.45)'; rrect(c, 440, 8, 400, 62, 20); c.fill();
      txt(c, `${teamGoals[0]}  -  ${teamGoals[1]}`, 640, 33, 44, '#fff', 'center', '900');
      txt(c, `${Math.max(0, Math.ceil(time))}s`, 640, 62, 22, '#ffd23f');
      c.fillStyle = TEAM[0]; c.fillRect(450, 14, 10, 40); c.fillStyle = TEAM[1]; c.fillRect(820, 14, 10, 40);
      txt(c, pls.filter((q) => q.team === 0).map((q) => q.p.name.slice(0, 7)).join('+'), 20, 35, 22, TEAM[0], 'left');
      txt(c, pls.filter((q) => q.team === 1).map((q) => q.p.name.slice(0, 7)).join('+'), W - 20, 35, 22, TEAM[1], 'right');
      if (banner) txt(c, banner, 640, CY, 130, '#ffd23f', 'center', '900');
    };
    return g;
  },
};
