import { W, H, txt, clamp, bg, hud, wrapPi } from './common.js';

const CX = 640, CY = 395, RXO = 580, RYO = 295, RXI = 310, RYI = 125, RXM = 445, RYM = 210, LAPS = 3, TAU = Math.PI * 2;
const ang = (x, y) => Math.atan2((y - CY) / RYM, (x - CX) / RXM);

export const racing = {
  create({ players, inp, say }) {
    let t = 0, firstFin = null, finished = 0;
    const cars = players.map((p, i) => {
      const x = 600 - i * 30, y = 140 + i * 34, a0 = ang(x, y);
      return { p, x, y, a: 0, v: 0, prog: Math.min(0, wrapPi(a0 + Math.PI / 2)), pa: a0, turbo: 1, fin: null, rank: 0 };
    });
    const onTrack = (x, y) => {
      const o = ((x - CX) / RXO) ** 2 + ((y - CY) / RYO) ** 2, n = ((x - CX) / RXI) ** 2 + ((y - CY) / RYI) ** 2;
      return o <= 1 && n >= 1;
    };
    const g = {
      over: false,
      update(dt) {
        t += dt;
        for (const c of cars) {
          const id = c.p.id;
          if (c.fin !== null) { c.v *= 0.98; }
          else {
            c.a += inp.dx(id) * 2.6 * dt * clamp(c.v / 150, 0.25, 1);
            const turbo = inp.held(id, 'a') && c.turbo > 0 && c.v > 50;
            let max = turbo ? 540 : 340;
            if (!onTrack(c.x, c.y)) max = 110;
            if (turbo) c.turbo = Math.max(0, c.turbo - dt * 0.6); else c.turbo = Math.min(1, c.turbo + dt * 0.15);
            if (inp.held(id, 'u')) c.v += (turbo ? 520 : 260) * dt; else c.v -= 130 * dt;
            if (c.v > max) c.v = Math.max(max, c.v - 700 * dt);
            c.v = Math.max(0, c.v);
          }
          c.x += Math.cos(c.a) * c.v * dt; c.y += Math.sin(c.a) * c.v * dt;
          c.x = clamp(c.x, 20, W - 20); c.y = clamp(c.y, 20, H - 20);
        }
        for (let i = 0; i < cars.length; i++) for (let j = i + 1; j < cars.length; j++) {
          const a = cars[i], b = cars[j], dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1;
          if (d < 30) { const k = (30 - d) / 2; a.x -= dx / d * k; a.y -= dy / d * k; b.x += dx / d * k; b.y += dy / d * k; }
        }
        for (const c of cars) {
          const na = ang(c.x, c.y); c.prog += wrapPi(na - c.pa); c.pa = na;
          if (c.fin === null && c.prog >= LAPS * TAU) {
            c.fin = t; c.rank = ++finished; if (firstFin === null) firstFin = t;
            say(c.p.id, `🏁 Terminaste en el puesto ${c.rank}`, 'i');
          }
        }
        if (finished === cars.length || (firstFin !== null && t - firstFin > 10) || t > 150) g.over = true;
      },
      scores() {
        return cars.map((c) => ({ user_id: c.p.id, score: g.scoreOf(c) }));
      },
      scoreOf(c) {
        const bonus = c.rank ? [400, 250, 120, 50][c.rank - 1] : 0;
        return Math.round(clamp(c.prog, 0, LAPS * TAU) / TAU * 300) + bonus;
      },
      draw(c) {
        bg(c, '#0a3fb8', '#06255f');
        c.fillStyle = '#2b3a5c'; c.beginPath(); c.ellipse(CX, CY, RXO, RYO, 0, 0, 7); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = 6; c.stroke();
        c.fillStyle = '#1fa86a'; c.beginPath(); c.ellipse(CX, CY, RXI, RYI, 0, 0, 7); c.fill(); c.stroke();
        c.setLineDash([22, 22]); c.strokeStyle = 'rgba(255,255,255,.45)'; c.lineWidth = 4;
        c.beginPath(); c.ellipse(CX, CY, RXM, RYM, 0, 0, 7); c.stroke(); c.setLineDash([]);
        c.fillStyle = '#fff'; for (let y = CY - RYO; y < CY - RYI; y += 20) { c.fillRect(CX - 5, y, 10, 10); c.fillRect(CX + 5, y + 10, 10, 10); }
        const order = cars.slice().sort((a, b) => b.prog - a.prog);
        order.forEach((car, i) => {
          const lap = clamp(Math.floor(Math.max(0, car.prog) / TAU) + 1, 1, LAPS);
          txt(c, `${i + 1}º ${car.p.name.slice(0, 10)}  ${car.fin !== null ? '🏁' : `V${lap}/${LAPS}`}`, CX, CY - 40 + i * 34, 28, car.p.color);
        });
        for (const car of cars) {
          c.save(); c.translate(car.x, car.y); c.rotate(car.a);
          c.fillStyle = car.p.color; c.fillRect(-18, -10, 36, 20);
          c.fillStyle = '#041a45'; c.fillRect(2, -7, 10, 14);
          c.fillStyle = '#fff'; c.fillRect(14, -9, 4, 4); c.fillRect(14, 5, 4, 4);
          c.restore();
          txt(c, car.p.name.slice(0, 8), car.x, car.y - 24, 18, '#fff');
        }
        hud(c, players, (p, i) => g.scoreOf(cars[i]));
        cars.forEach((car, i) => { c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(20 + i * 310, 62, 300, 8); c.fillStyle = '#ffd23f'; c.fillRect(20 + i * 310, 62, 300 * car.turbo, 8); });
        txt(c, `${Math.max(0, Math.ceil(150 - t))}s`, W - 20, 100, 26, '#fff', 'right');
      },
    };
    return g;
  },
};
