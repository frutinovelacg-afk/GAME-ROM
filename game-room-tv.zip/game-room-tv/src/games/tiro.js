import { W, H, txt, clamp, rnd, bg, hud, dist } from './common.js';

const DUR = 45;

export const tiro = {
  create({ players, inp }) {
    let time = DUR, spawn = 0;
    const pls = players.map((p, i) => ({ p, x: 280 + i * 240, y: 400, cd: 0, score: 0, hits: 0 }));
    const targets = [], fx = [];
    const add = () => {
      const gold = Math.random() < 0.12, r = gold ? 28 : rnd(34, 70);
      targets.push({ x: rnd(90, W - 90), y: rnd(130, H - 90), r, life: gold ? 1.8 : rnd(2.4, 3.8), age: 0, vx: gold ? rnd(-220, 220) : 0, vy: gold ? rnd(-120, 120) : 0, pts: gold ? 250 : Math.round((160 - r * 1.5) / 5) * 5, gold });
    };
    const g = { over: false };
    g.update = (dt) => {
      time -= dt; if (time <= 0) { g.over = true; return; }
      spawn -= dt; if (spawn <= 0 && targets.length < 7) { add(); spawn = 0.55; }
      for (let i = targets.length - 1; i >= 0; i--) {
        const t = targets[i]; t.age += dt; t.x += t.vx * dt; t.y += t.vy * dt;
        if (t.x < t.r || t.x > W - t.r) t.vx *= -1; if (t.y < 100 + t.r || t.y > H - t.r) t.vy *= -1;
        if (t.age > t.life) targets.splice(i, 1);
      }
      for (const q of pls) {
        q.x = clamp(q.x + inp.dx(q.p.id) * 430 * dt, 10, W - 10); q.y = clamp(q.y + inp.dy(q.p.id) * 430 * dt, 90, H - 10); q.cd -= dt;
        if (inp.pressed(q.p.id, 'a') && q.cd <= 0) {
          q.cd = 0.22;
          let hit = -1, best = 1e9;
          targets.forEach((t, i) => { const d = dist(q.x, q.y, t.x, t.y); if (d <= t.r && d < best) { best = d; hit = i; } });
          if (hit >= 0) { const t = targets.splice(hit, 1)[0]; q.score += t.pts; q.hits++; fx.push({ x: t.x, y: t.y, s: `+${t.pts}`, c: q.p.color, a: 0 }); }
          else fx.push({ x: q.x, y: q.y, s: '✕', c: '#ffffff88', a: 0 });
        }
      }
      for (let i = fx.length - 1; i >= 0; i--) { fx[i].a += dt; if (fx[i].a > 0.8) fx.splice(i, 1); }
    };
    g.scores = () => pls.map((q) => ({ user_id: q.p.id, score: q.score }));
    g.draw = (c) => {
      bg(c, '#0a3fb8', '#06307f');
      for (const t of targets) {
        const k = 1 - Math.max(0, t.age - (t.life - 0.6)) / 0.6 * 0.6;
        const cols = t.gold ? ['#ffd23f', '#fff', '#ffd23f'] : ['#ff5468', '#fff', '#ff5468'];
        [1, 0.66, 0.33].forEach((s, i) => { c.fillStyle = cols[i]; c.beginPath(); c.arc(t.x, t.y, t.r * s * k, 0, 7); c.fill(); });
        txt(c, t.pts, t.x, t.y - t.r - 14, 18, '#fff');
      }
      for (const q of pls) {
        c.strokeStyle = q.p.color; c.lineWidth = 5; c.beginPath(); c.arc(q.x, q.y, 24, 0, 7);
        c.moveTo(q.x - 36, q.y); c.lineTo(q.x + 36, q.y); c.moveTo(q.x, q.y - 36); c.lineTo(q.x, q.y + 36); c.stroke();
        txt(c, q.p.name.slice(0, 8), q.x, q.y + 46, 18, q.p.color);
      }
      for (const f of fx) txt(c, f.s, f.x, f.y - f.a * 60, 36, f.c);
      hud(c, players, (p, i) => pls[i].score, `${Math.max(0, Math.ceil(time))}s`);
    };
    return g;
  },
};
