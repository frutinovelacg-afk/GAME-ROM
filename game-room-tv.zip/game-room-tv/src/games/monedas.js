import { W, H, txt, clamp, rnd, bg, dist } from './common.js';

const DUR = 45;

export const monedas = {
  create({ players, inp }) {
    let time = DUR, spawn = 0;
    const P = players.map((p, i) => ({ p, x: 240 + i * 270, y: 400, stun: 0, coins: 0, stars: 0, bombs: 0 }));
    const items = [];
    const sc = (q) => Math.max(0, q.coins * 10 + q.stars * 50 - q.bombs * 30);
    const g = { over: false };
    g.update = (dt) => {
      time -= dt; if (time <= 0) { g.over = true; return; }
      spawn -= dt;
      if (spawn <= 0 && items.length < 14) {
        const r = Math.random(), type = r < 0.68 ? 'coin' : r < 0.78 ? 'star' : 'bomb';
        items.push({ type, x: rnd(60, W - 60), y: rnd(130, H - 50), age: 0, life: type === 'bomb' ? 6 : type === 'star' ? 5 : 8 });
        spawn = 0.4;
      }
      for (let i = items.length - 1; i >= 0; i--) { items[i].age += dt; if (items[i].age > items[i].life) items.splice(i, 1); }
      for (const q of P) {
        q.stun -= dt;
        if (q.stun <= 0) { q.x = clamp(q.x + inp.dx(q.p.id) * 330 * dt, 30, W - 30); q.y = clamp(q.y + inp.dy(q.p.id) * 330 * dt, 100, H - 30); }
        for (let i = items.length - 1; i >= 0; i--) {
          const it = items[i];
          if (dist(q.x, q.y, it.x, it.y) < 26 + 16) {
            if (it.type === 'coin') q.coins++; else if (it.type === 'star') q.stars++; else { q.bombs++; q.stun = 1; }
            items.splice(i, 1);
          }
        }
      }
    };
    g.scores = () => P.map((q) => ({ user_id: q.p.id, score: sc(q) }));
    const star = (c, x, y, r) => { c.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; c.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } c.closePath(); c.fill(); };
    g.draw = (c) => {
      bg(c, '#0a3fb8', '#06307f');
      for (const it of items) {
        const fade = it.life - it.age < 1.2 && Math.floor(it.age * 10) % 2 === 0; if (fade) continue;
        if (it.type === 'coin') { c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(it.x, it.y, 16, 0, 7); c.fill(); c.strokeStyle = '#b58f00'; c.lineWidth = 4; c.stroke(); }
        else if (it.type === 'star') { c.fillStyle = '#fff'; star(c, it.x, it.y, 24); }
        else { c.fillStyle = '#1b1f33'; c.beginPath(); c.arc(it.x, it.y, 18, 0, 7); c.fill(); c.strokeStyle = '#ff5468'; c.lineWidth = 4; c.stroke(); txt(c, '!', it.x, it.y, 22, '#ff5468'); }
      }
      for (const q of P) {
        c.fillStyle = q.stun > 0 ? '#7d8aa8' : q.p.color; c.beginPath(); c.arc(q.x, q.y, 26, 0, 7); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = 4; c.stroke();
        txt(c, q.p.name.slice(0, 8), q.x, q.y - 40, 20, '#fff');
      }
      txt(c, `${Math.max(0, Math.ceil(time))}s`, W - 20, 82, 28, '#fff', 'right');
      P.forEach((q, i) => {
        const x = 20 + i * 310;
        c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(x, 12, 300, 46);
        c.fillStyle = q.p.color; c.beginPath(); c.arc(x + 22, 35, 11, 0, 7); c.fill();
        txt(c, q.p.name.slice(0, 7), x + 40, 35, 20, '#fff', 'left');
        c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(x + 150, 35, 9, 0, 7); c.fill(); txt(c, q.coins, x + 164, 35, 20, '#fff', 'left');
        c.fillStyle = '#fff'; star(c, x + 205, 35, 11); txt(c, q.stars, x + 220, 35, 20, '#fff', 'left');
        txt(c, sc(q), x + 292, 35, 24, q.p.color, 'right', '900');
      });
    };
    return g;
  },
};
