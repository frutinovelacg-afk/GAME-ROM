export const BIT = { l: 1, r: 2, u: 4, d: 8, a: 16, b: 32 };

// Estado de botones de todos los celulares (recibido por Supabase Realtime)
export class Input {
  constructor() { this.reset(); }
  reset() { this.m = {}; this.pm = {}; this.ts = {}; this.pr = {}; this.rl = {}; this.ans = []; }
  onKey(p) { if (!p || !p.u) return; this.m[p.u] = p.m | 0; this.ts[p.u] = performance.now(); }
  onAns(p) { if (p && p.u) this.ans.push(p); }
  tick(now) {
    for (const u in this.m) {
      if (this.m[u] && now - this.ts[u] > 800) this.m[u] = 0; // el celular dejó de enviar: soltar botones
      const cur = this.m[u], prev = this.pm[u] || 0;
      this.pr[u] = cur & ~prev; this.rl[u] = prev & ~cur; this.pm[u] = cur;
    }
  }
  held(u, k) { return !!((this.m[u] || 0) & BIT[k]); }
  pressed(u, k) { return !!((this.pr[u] || 0) & BIT[k]); }
  released(u, k) { return !!((this.rl[u] || 0) & BIT[k]); }
  dx(u) { return (this.held(u, 'r') ? 1 : 0) - (this.held(u, 'l') ? 1 : 0); }
  dy(u) { return (this.held(u, 'd') ? 1 : 0) - (this.held(u, 'u') ? 1 : 0); }
  take() { const a = this.ans; this.ans = []; return a; }
}
