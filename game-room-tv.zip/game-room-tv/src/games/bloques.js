import { W, H, txt, clamp, rnd, bg, hud, rrect } from './common.js';

const COLS = 14, ROWS = 6, BW = 82, BH = 28, GAP = 6, BX = (W - (COLS * (BW + GAP) - GAP)) / 2, BY = 100, PW = 130, PY = 686, R = 10;
const ROWC = ['#ffffff', '#d6e8ff', '#a9ceff', '#7db3ff', '#4f97ff', '#2b7bff'];

export const bloques = {
  create({ players, inp }) {
    let t = 0;
    const bricks = [];
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) bricks.push({ x: BX + c * (BW + GAP), y: BY + r * (BH + GAP), r, alive: true });
    const P = players.map((p, i) => ({ p, px: 200 + i * 290, lives: 3, score: 0, held: 1, ball: { x: 0, y: 0, vx: 0, vy: 0 }, sp: 430 }));
    const g = { over: false };
    for (const q of P) { q.ball.x = q.px; q.ball.y = PY - R - 2; }
    g.update = (dt) => {
      t += dt;
      for (const q of P) {
        if (q.lives <= 0) continue;
        q.px = clamp(q.px + inp.dx(q.p.id) * 650 * dt, PW / 2, W - PW / 2);
        const b = q.ball;
        if (q.held > 0) {
          q.held -= dt; b.x = q.px; b.y = PY - R - 2;
          if (q.held <= 0 || inp.pressed(q.p.id, 'a')) { const a = rnd(-0.5, 0.5); b.vx = Math.sin(a) * q.sp; b.vy = -Math.cos(a) * q.sp; q.held = 0; }
          continue;
        }
        b.x += b.vx * dt; b.y += b.vy * dt;
        if (b.x < R) { b.x = R; b.vx = Math.abs(b.vx); } if (b.x > W - R) { b.x = W - R; b.vx = -Math.abs(b.vx); }
        if (b.y < R) { b.y = R; b.vy = Math.abs(b.vy); }
        if (b.vy > 0 && b.y + R >= PY && b.y + R <= PY + 24 && Math.abs(b.x - q.px) <= PW / 2 + R) {
          const rel = clamp((b.x - q.px) / (PW / 2), -1, 1), a = rel * 1.1;
          b.vx = Math.sin(a) * q.sp; b.vy = -Math.cos(a) * q.sp; b.y = PY - R;
        }
        for (const k of bricks) {
          if (!k.alive) continue;
          const cx = clamp(b.x, k.x, k.x + BW), cy = clamp(b.y, k.y, k.y + BH), dx = b.x - cx, dy = b.y - cy;
          if (dx * dx + dy * dy <= R * R) {
            k.alive = false; q.score += 10; q.sp = Math.min(700, q.sp + 6);
            if (Math.abs(dx) > Math.abs(dy)) b.vx = dx > 0 ? Math.abs(b.vx) : -Math.abs(b.vx); else b.vy = dy > 0 ? Math.abs(b.vy) : -Math.abs(b.vy);
            const s = Math.hypot(b.vx, b.vy) || 1; b.vx = b.vx / s * q.sp; b.vy = b.vy / s * q.sp;
            break;
          }
        }
        if (b.y > H + 20) { q.lives--; q.held = 1; q.sp = Math.max(430, q.sp - 40); b.x = q.px; b.y = PY - R - 2; b.vx = b.vy = 0; }
      }
      if (!bricks.some((k) => k.alive) || P.every((q) => q.lives <= 0) || t > 150) g.over = true;
    };
    const sc = (q) => q.score + q.lives * 20;
    g.scores = () => P.map((q) => ({ user_id: q.p.id, score: sc(q) }));
    g.draw = (c) => {
      bg(c, '#06307f', '#041a45');
      for (const k of bricks) if (k.alive) { c.fillStyle = ROWC[k.r]; rrect(c, k.x, k.y, BW, BH, 7); c.fill(); }
      for (const q of P) {
        if (q.lives <= 0) continue;
        c.fillStyle = q.p.color; rrect(c, q.px - PW / 2, PY, PW, 16, 8); c.fill();
        c.beginPath(); c.arc(q.ball.x, q.ball.y, R, 0, 7); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = 2; c.stroke();
      }
      hud(c, P.map((q) => q.p), (p, i) => `${'♥'.repeat(Math.max(0, P[i].lives))} ${sc(P[i])}`);
    };
    return g;
  },
};
