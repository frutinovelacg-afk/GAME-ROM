export const $ = (s, r = document) => r.querySelector(s);
export const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let tt;
export function toast(msg, ms = 3000) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(tt);
  tt = setTimeout(() => el.classList.remove('show'), ms);
}

export function errText(e) {
  const m = (e && (e.message || e.error_description)) || String(e || 'Error');
  return m.replace(/^.*?:\s*(?=[A-ZÁÉÍÓÚ])/, '');
}
