import { getClient } from '../supabase.js';
import { openRoomChannel } from '../net.js';
import { esc, errText } from '../ui.js';
import { GAMES, byId } from '../games/catalog.js';
import { Input } from '../games/input.js';
import { playGame } from '../games/engine.js';
import { COLORS } from '../games/common.js';

export async function startTV(root) {
  const sb = getClient('tv');
  const wrap = document.getElementById('stagewrap');
  const canvas = document.getElementById('stage');
  const inp = new Input();
  const S = { room: null, players: [], chat: [], results: [], ch: null, stop: null, syncT: null, closedTimer: null };
  const joinUrl = `${location.origin}${location.pathname}#/phone`;

  const loading = (t = '') => { root.innerHTML = `<div class="screen center"><div class="spinner"></div><p class="codehint">${esc(t)}</p></div>`; };
  const fatal = (e) => {
    root.innerHTML = `<div class="screen center"><div class="card narrow"><h2>No se pudo iniciar la TV</h2><p>${esc(errText(e))}</p>
      <p>Revisa que ejecutaste el SQL y activaste <b>Anonymous sign-ins</b> en Supabase (Authentication → Sign In / Providers).</p>
      <button class="bigbtn" onclick="location.reload()">Reintentar</button></div></div>`;
  };

  loading('Creando sala…');
  try {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) { const { error } = await sb.auth.signInAnonymously(); if (error) throw error; }
    await openOrCreate();
  } catch (e) { return fatal(e); }

  async function openOrCreate() {
    let room = null;
    const saved = localStorage.getItem('grtv-room');
    if (saved) {
      const { data } = await sb.from('rooms').select('*').eq('id', saved).maybeSingle();
      if (data && !data.closed) room = data;
    }
    if (!room) {
      const { data, error } = await sb.rpc('create_room');
      if (error) throw error;
      room = data; localStorage.setItem('grtv-room', room.id);
    }
    S.room = room; S.chat = []; S.players = [];
    if (S.ch) { sb.removeChannel(S.ch); S.ch = null; }
    S.ch = openRoomChannel(sb, room.id, {
      onRoom: scheduleSync, onPlayers: scheduleSync,
      onChat: (m) => { if (!S.chat.some((x) => x.id === m.id)) { S.chat.push(m); if (S.chat.length > 40) S.chat.shift(); if (S.room && S.room.status === 'lobby') renderChat(); } },
      onKey: (p) => inp.onKey(p), onAns: (p) => inp.onAns(p),
      onStatus: (s) => { if (s === 'SUBSCRIBED') sync(); },
    });
    const { data: msgs } = await sb.from('chat_messages').select('*').eq('room_id', room.id).order('id', { ascending: false }).limit(12);
    S.chat = (msgs || []).reverse();
    await sync();
  }

  const scheduleSync = () => { clearTimeout(S.syncT); S.syncT = setTimeout(sync, 80); };
  setInterval(sync, 4000);
  setInterval(() => { if (S.room && !S.room.closed) sb.rpc('prune_players', { p_room: S.room.id }).then(() => {}, () => {}); }, 10000);

  async function sync() {
    if (!S.room) return;
    try {
      const [r, p] = await Promise.all([
        sb.from('rooms').select('*').eq('id', S.room.id).maybeSingle(),
        sb.from('room_players').select('*').eq('room_id', S.room.id).order('joined_at'),
      ]);
      if (r.error || p.error || !r.data) return;
      const prev = S.room.status;
      S.room = r.data; S.players = p.data || [];
      if (S.room.closed) return closedScreen();
      if (S.room.status === 'playing' && prev !== 'playing' && !S.stop) startGame();
      else if (S.room.status !== 'playing' && S.stop) stopGame();
      if (S.room.status === 'results' && !S.results.length) await loadResults();
      if (S.room.status !== 'results' && prev === 'results') S.results = [];
      render();
    } catch (_) { /* se reintenta con el sondeo */ }
  }

  function closedScreen() {
    if (S.stop) stopGame();
    localStorage.removeItem('grtv-room');
    root.classList.remove('hidden');
    root.innerHTML = `<div class="screen center"><h1 class="big-title">SALA CERRADA</h1><p class="codehint">Creando una sala nueva…</p></div>`;
    S.room = null;
    clearTimeout(S.closedTimer);
    S.closedTimer = setTimeout(() => openOrCreate().catch(fatal), 2500);
  }

  async function loadResults() {
    const { data } = await sb.from('game_results').select('*').eq('room_id', S.room.id).order('created_at', { ascending: false }).order('position').limit(8);
    if (!data || !data.length) return;
    const t = data[0].created_at;
    S.results = data.filter((x) => x.created_at === t).sort((a, b) => a.position - b.position);
  }

  // ---------- Partida ----------
  function startGame() {
    const meta = byId(S.room.game_id);
    if (!meta) return;
    const players = S.players.slice(0, 4).map((p, i) => ({ id: p.user_id, name: p.username, color: COLORS[i], idx: i }));
    inp.reset();
    root.classList.add('hidden'); wrap.classList.remove('hidden');
    const say = (u, t, k) => { if (S.ch) S.ch.send({ type: 'broadcast', event: 'msg', payload: { u, t, k } }); };
    S.stop = playGame({
      canvas, meta, players, inp, say,
      onEnd: async (scores) => {
        S.stop = null;
        const { error } = await sb.rpc('finish_game', { p_room: S.room.id, p_results: scores });
        wrap.classList.add('hidden'); root.classList.remove('hidden');
        if (error) { root.innerHTML = `<div class="screen center"><div class="card narrow"><h2>No se pudieron guardar los resultados</h2><p>${esc(errText(error))}</p></div></div>`; setTimeout(sync, 3000); return; }
        S.results = [];
        await sync();
      },
    });
  }
  function stopGame() {
    if (S.stop) { S.stop(); S.stop = null; }
    wrap.classList.add('hidden'); root.classList.remove('hidden');
  }

  // ---------- Pantallas ----------
  function render() {
    if (!S.room || S.room.status === 'playing') return;
    root.classList.remove('hidden');
    const st = S.room.status;
    root.innerHTML = st === 'lobby' ? lobby() : st === 'menu' ? menu() : results();
    if (st === 'lobby') renderChat();
  }
  const slots = () => Array.from({ length: 4 }, (_, i) => {
    const p = S.players[i];
    return p ? `<div class="pl"><span class="dot" style="background:${COLORS[i]}"></span>${p.is_admin ? '👑' : '🎮'} ${esc(p.username)}${p.is_admin ? '<span class="tag">👑 ADMIN</span>' : ''}</div>`
      : '<div class="pl empty">👤 Esperando jugador…</div>';
  }).join('');
  const adminName = () => { const a = S.players.find((p) => p.is_admin); return a ? a.username : ''; };

  function lobby() {
    const n = S.players.length;
    const status = n === 0 ? 'Esperando jugadores…' : n < 2 ? 'Necesitas al menos 2 jugadores para comenzar.' : 'Esperando al administrador...';
    return `<div class="screen">
      <h1 class="tv-title">GAME ROOM</h1>
      <div class="tv-lobby">
        <div class="stack" style="display:flex;flex-direction:column;gap:16px">
          <div class="codebox"><small>CÓDIGO DE SALA</small><b>${esc(S.room.code)}</b></div>
          <p class="codehint">Introduce este código desde tu celular para entrar.</p>
          <div class="count">JUGADORES ${n}/4</div>
          <div class="plist">${slots()}</div>
        </div>
        <div class="glass chatpanel"><h3>💬 Chat</h3><div id="chatlog"></div></div>
      </div>
      <div class="status">${status}</div>
      <p class="codehint">En tu celular abre: <b>${esc(joinUrl)}</b></p>
    </div>`;
  }
  function renderChat() {
    const el = document.getElementById('chatlog'); if (!el) return;
    el.innerHTML = S.chat.slice(-8).map((m) => `<div class="msg"><b>${esc(m.username)}:</b> ${esc(m.body)}</div>`).join('') || '<div class="msg">Aún no hay mensajes</div>';
    el.scrollTop = el.scrollHeight;
  }
  function menu() {
    const sel = byId(S.room.game_id);
    return `<div class="screen">
      <h1 class="big-title">ELIGE UN JUEGO</h1>
      <div class="menu-grid">${GAMES.map((g) => `<div class="tile ${sel && sel.id === g.id ? 'sel' : ''}"><span class="e">${g.emoji}</span>${g.name}</div>`).join('')}</div>
      <div class="status">${sel ? `${sel.emoji} <b>${sel.name}</b> — ${esc(sel.rules)}` : `👑 ${esc(adminName())} elige el juego desde su celular`}</div>
    </div>`;
  }
  function results() {
    const medal = ['🥇', '🥈', '🥉'];
    const w = S.results[0];
    return `<div class="screen">
      <h1 class="big-title">🏆 RESULTADOS</h1>
      ${w ? `<p class="codehint" style="font-size:clamp(22px,3vw,44px)">¡Ganó ${esc(w.username)}!</p>` : ''}
      <div class="results">${S.results.map((r) => `<div class="rrow"><span>${medal[r.position - 1] || r.position + '.º'}</span><span>${esc(r.username)}</span><span class="sc">${r.score} puntos</span></div>`).join('') || '<div class="rrow">Guardando resultados…</div>'}</div>
      <div class="nav3"><div>🔄 JUGAR OTRA VEZ</div><div>🎮 ELEGIR OTRO JUEGO</div><div>🚪 SALIR DE LA SALA</div></div>
      <p class="codehint">👑 ${esc(adminName())} decide desde su celular</p>
    </div>`;
  }
}
