import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const configured = Boolean(url && key);

const clients = {};
// Un cliente por modo (tv / phone) con almacenamiento de sesión separado,
// así se puede probar TV y celular en el mismo navegador.
export function getClient(mode) {
  if (!clients[mode]) {
    clients[mode] = createClient(url, key, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, storageKey: `grtv-${mode}-auth` },
      realtime: { params: { eventsPerSecond: 40 } },
    });
  }
  return clients[mode];
}
