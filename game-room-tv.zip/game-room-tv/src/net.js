// Canal único por sala: cambios de base de datos + mensajes broadcast (controles).
export function openRoomChannel(sb, roomId, h) {
  const ch = sb.channel(`room:${roomId}`, { config: { broadcast: { self: false, ack: false } } });
  ch.on('postgres_changes', { event: '*', schema: 'public', table: 'rooms', filter: `id=eq.${roomId}` }, (p) => h.onRoom && h.onRoom(p))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'room_players', filter: `room_id=eq.${roomId}` }, (p) => h.onPlayers && h.onPlayers(p))
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `room_id=eq.${roomId}` }, (p) => h.onChat && h.onChat(p.new))
    .on('broadcast', { event: 'k' }, (p) => h.onKey && h.onKey(p.payload))
    .on('broadcast', { event: 'ans' }, (p) => h.onAns && h.onAns(p.payload))
    .on('broadcast', { event: 'msg' }, (p) => h.onMsg && h.onMsg(p.payload))
    .subscribe((status) => h.onStatus && h.onStatus(status));
  return ch;
}
