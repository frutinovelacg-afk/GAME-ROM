import { getClient } from '../supabase.js';
import { openRoomChannel } from '../net.js';
import { esc, toast, errText } from '../ui.js';
import { GAMES, byId } from '../games/catalog.js';
import { COLORS } from '../games/common.js';
import { buildController } from './controller.js';

const USER_RE = /^[A-Za-z0-9_]{3,16}$/;
const emailOf = (u) => `${u.toLowerCase()}@gameroom.app`;

export async function startPhone(root) {
  const sb = getClient('phone');
  const S = { profile: null, room: null, players: [], chat: [], results: [], ch: null, view: '', hb: null, poll: null, ctrl: null, confirmMenu: false, syncT: null, busy: false };
  const $ = (s) => root.querySelector(s);
  const me = () => S.profile && S.profile.id;
  const isAdmin = () => !!S.room && S.room.admin_id === me();

  // ---------- Delegación de eventos ----------
  const actions = {};
  root.addEventListener('click', (e) => {
    const b = e.target.closest('[data-a]');
    if (b && actions[b.dataset.a]) actions[b.dataset.a](b, e);
  });
  root.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (e.target.id === 'chatin') actions.send();
    else if (e.target.id === 'p' && $('[data-a=submit]')) actions.submit($('[data-a=submit]'));
    else if (e.target.id === 'code') actions.join();
  });
  const screen = (html) => { root.innerHTML = `<div class="screen phone">${html}</div>`; };

  // ---------- Autenticación ----------
  function authChoice() {
    cleanupRoom();
    screen(`
      <div class="stack" style="margin:auto 0">
        <h2 style="font-size:34px;text-align:center">📱 Tu control</h2>
        <button class="bigbtn" data-a="signup">CREAR CUENTA</button>
        <button class="bigbtn alt" data-a="login">INICIAR SESIÓN</button>
        <button class="ghost" data-a="home">⬅ Volver</button>
      </div>`);
  }
  function authForm(mode) {
    const up = mode === 'signup';
    screen(`
      <div class="stack" style="margin:auto 0">
        <h2 style="font-size:30px;text-align:center">${up ? 'CREAR CUENTA' : 'INICIAR SESIÓN'}</h2>
        <input class="field" id="u" placeholder="Usuario" autocomplete="username" autocapitalize="none" maxlength="16" />
        <input class="field" id="p" type="password" placeholder="Contraseña" autocomplete="${up ? 'new-password' : 'current-password'}" />
        ${up ? '<div class="note">Usuario: 3 a 16 letras, números o _. Contraseña: mínimo 6 caracteres.</div>' : ''}
        <div class="err" id="err"></div>
        <button class="bigbtn" data-a="submit" data-mode="${mode}">${up ? 'CREAR CUENTA' : 'INICIAR SESIÓN'}</button>
        <button class="ghost" data-a="back">⬅ Volver</button>
      </div>`);
  }
  const showErr = (m) => { const e = $('#err'); if (e) { e.textContent = m; e.classList.add('show'); } else toast(m); };

  actions.home = () => { location.hash = ''; };
  actions.signup = () => authForm('signup');
  actions.login = () => authForm('login');
  actions.back = () => authChoice();
  actions.submit = async (btn) => {
    if (S.busy) return;
    const up = btn.dataset.mode === 'signup', u = $('#u').value.trim(), p = $('#p').value;
    if (!USER_RE.test(u)) return showErr('El usuario debe tener 3 a 16 caracteres: letras, números o _.');
    if (p.length < 6) return showErr('La contraseña debe tener al menos 6 caracteres.');
    S.busy = true; btn.disabled = true;
    try {
      if (up) {
        const { error } = await sb.auth.signUp({ email: emailOf(u), password: p, options: { data: { username: u } } });
        if (error) throw error;
      }
      const { error } = await sb.auth.signInWithPassword({ email: emailOf(u), password: p });
      if (error) throw error;
      await loadProfile();
      if (!S.profile) throw new Error('No se pudo crear el perfil. Revisa que ejecutaste el SQL.');
      codeScreen();
    } catch (e) {
      const m = errText(e);
      showErr(/already registered|already been registered/i.test(m) ? 'Ese usuario ya existe. Elige otro o inicia sesión.'
        : /invalid login/i.test(m) ? 'Usuario o contraseña incorrectos.'
        : /not confirmed/i.test(m) ? 'Desactiva "Confirm email" en Supabase Auth.'
        : m);
      btn.disabled = false;
    }
    S.busy = false;
  };
  async function loadProfile() {
    const { data: { user } } = await sb.auth.getUser();
    if (!user) { S.profile = null; return; }
    const { data } = await sb.from('profiles').select('*').eq('id', user.id).maybeSingle();
    S.profile = data || null;
  }
  actions.logout = async () => { cleanupRoom(); localStorage.removeItem('grtv-code'); await sb.auth.signOut(); S.profile = null; authChoice(); };

  // ---------- Código de sala ----------
  function codeScreen(err) {
    cleanupRoom();
    screen(`
      <div class="topbar"><div class="code">👤 ${esc(S.profile.username)}</div><button class="mini" data-a="profile">MI PERFIL</button><button class="mini" data-a="logout">Salir</button></div>
      <div class="stack" style="margin:auto 0">
        <h2 style="font-size:28px;text-align:center">INTRODUCE EL CÓDIGO DE LA TV</h2>
        <input class="field code" id="code" placeholder="K7F2" maxlength="4" autocomplete="off" autocapitalize="characters" inputmode="text" />
        <div class="err ${err ? 'show' : ''}" id="err">${esc(err || '')}</div>
        <button class="bigbtn" data-a="join">UNIRME A LA SALA</button>
      </div>`);
  }
  actions.join = async () => {
    const code = ($('#code').value || '').trim().toUpperCase();
    if (code.length !== 4) return showErr('El código tiene 4 caracteres.');
    const btn = $('[data-a=join]'); btn.disabled = true;
    const { data, error } = await sb.rpc('join_room', { p_code: code });
    if (error) { btn.disabled = false; return showErr(errText(error)); }
    localStorage.setItem('grtv-code', code);
    enterRoom(data);
  };

  // ---------- Sala ----------
  function enterRoom(room) {
    cleanupRoom();
    S.room = room; S.players = []; S.chat = []; S.view = '';
    S.ch = openRoomChannel(sb, room.id, {
      onRoom: scheduleSync, onPlayers: scheduleSync,
      onChat: (m) => addChat(m),
      onMsg: (p) => { if (!p || (p.u && p.u !== me())) return; const el = $('#ctrlmsg'); if (el) el.textContent = p.t || ''; if (p.k === 'q' && S.ctrl) S.ctrl.resetQuiz(); },
      onStatus: (s) => { if (s === 'SUBSCRIBED') { sync(); } },
    });
    S.hb = setInterval(heartbeat, 5000);
    S.poll = setInterval(sync, 4000);
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('online', onVis);
    sync();
  }
  function onVis() { if (!document.hidden) { heartbeat(); sync(); } }
  function cleanupRoom() {
    if (S.ctrl) { S.ctrl.destroy(); S.ctrl = null; }
    if (S.ch) { sb.removeChannel(S.ch); S.ch = null; }
    clearInterval(S.hb); clearInterval(S.poll); clearTimeout(S.syncT);
    document.removeEventListener('visibilitychange', onVis);
    window.removeEventListener('online', onVis);
    S.room = null;
  }
  const scheduleSync = () => { clearTimeout(S.syncT); S.syncT = setTimeout(sync, 80); };

  async function heartbeat() {
    if (!S.room) return;
    try {
      const { data, error } = await sb.rpc('touch_player', { p_room: S.room.id });
      if (error) return; // sin red: se reintenta en el próximo latido
      if (data === false) await rejoin();
    } catch (_) { /* sin conexión */ }
  }
  async function rejoin() {
    const code = localStorage.getItem('grtv-code');
    if (!code) return leaveToCode();
    const { data, error } = await sb.rpc('join_room', { p_code: code });
    if (error) return leaveToCode(errText(error));
    S.room = data;
  }
  function leaveToCode(msg) { localStorage.removeItem('grtv-code'); codeScreen(msg); }

  async function sync() {
    if (!S.room) return;
    const id = S.room.id;
    try {
      const [r, p] = await Promise.all([
        sb.from('rooms').select('*').eq('id', id).maybeSingle(),
        sb.from('room_players').select('*').eq('room_id', id).order('joined_at'),
      ]);
      if (r.error || p.error) return;
      if (!r.data || r.data.closed) return leaveToCode('La sala se cerró.');
      S.room = r.data; S.players = p.data || [];
      if (!S.players.some((x) => x.user_id === me())) { await rejoin(); if (!S.room) return; }
      if (!S.chat.length) await loadChat();
      paint();
    } catch (_) { /* reintenta con el sondeo */ }
  }
  async function loadChat() {
    const { data } = await sb.from('chat_messages').select('*').eq('room_id', S.room.id).order('id', { ascending: false }).limit(30);
    S.chat = (data || []).reverse(); renderChat();
  }
  function addChat(m) {
    if (!m || S.chat.some((x) => x.id === m.id)) return;
    S.chat.push(m); if (S.chat.length > 60) S.chat.shift(); renderChat();
  }
  function renderChat() {
    const el = $('#chatlog'); if (!el) return;
    el.innerHTML = S.chat.slice(-30).map((m) => `<div class="msg"><b>${esc(m.username)}:</b> ${esc(m.body)}</div>`).join('');
    el.scrollTop = el.scrollHeight;
  }

  // ---------- Pintado por vista ----------
  function paint() {
    const r = S.room, view = `${r.status}:${isAdmin() ? 'A' : 'P'}:${r.status === 'playing' ? r.game_id : ''}`;
    if (view !== S.view) {
      if (S.ctrl && r.status !== 'playing') { S.ctrl.destroy(); S.ctrl = null; }
      S.view = view; S.confirmMenu = false;
      ({ lobby: buildLobby, menu: buildMenu, playing: buildPlaying, results: buildResults })[r.status]();
    }
    ({ lobby: updLobby, menu: updMenu, playing: () => {}, results: updResults })[r.status]();
  }
  const rpc = async (fn, args, ok) => {
    const { error } = await sb.rpc(fn, args);
    if (error) toast(errText(error)); else if (ok) ok();
    sync();
  };
  const topbar = () => `<div class="topbar"><div class="code">SALA <b>${esc(S.room.code)}</b>${isAdmin() ? ' <span class="tag" style="margin-left:6px;padding:2px 8px">👑 ADMIN</span>' : ''}</div><button class="mini" data-a="profile">👤</button><button class="mini" data-a="leave">🚪 SALIR</button></div>`;

  // Sala de espera
  function buildLobby() {
    screen(`${topbar()}
      <div id="plist" class="plist"></div>
      <div id="lobbymsg" class="note"></div>
      <div class="chat"><div id="chatlog" class="chatlog"></div>
        <div class="chatrow"><input id="chatin" maxlength="140" placeholder="Escribe un mensaje..." enterkeyhint="send" autocomplete="off" /><button data-a="send">➤</button></div></div>
      ${isAdmin() ? `<button class="bigbtn" data-a="pick">🎮 ELEGIR JUEGO</button><button class="ghost danger" data-a="close">🔒 CERRAR SALA</button>` : ''}`);
    renderChat();
  }
  function updLobby() {
    const n = S.players.length, admin = isAdmin();
    $('#plist').innerHTML = S.players.map((p, i) => `<div class="pl"><span class="dot" style="background:${COLORS[i]}"></span>${p.is_admin ? '👑' : '🎮'} ${esc(p.username)}${p.user_id === me() ? ' (tú)' : ''}${p.is_admin ? '<span class="tag">ADMIN</span>' : admin ? `<button class="kick" data-a="kick" data-u="${p.user_id}">Expulsar</button>` : ''}</div>`).join('') + `<div class="note">${n}/4 jugadores</div>`;
    $('#lobbymsg').textContent = n < 2 ? 'Necesitas al menos 2 jugadores para comenzar.' : admin ? 'Todo listo. Elige un juego.' : 'Esperando al administrador...';
  }
  actions.send = async () => {
    const el = $('#chatin'); if (!el) return;
    const body = el.value.trim().slice(0, 140); if (!body) return;
    el.value = '';
    const { error } = await sb.from('chat_messages').insert({ room_id: S.room.id, user_id: me(), username: S.profile.username, body });
    if (error) toast('No se pudo enviar el mensaje');
  };
  actions.pick = () => rpc('set_room_state', { p_room: S.room.id, p_status: 'menu' });
  actions.close = () => { if (confirm('¿Cerrar la sala para todos?')) rpc('close_room', { p_room: S.room.id }); };
  actions.kick = (b) => { if (confirm('¿Expulsar a este jugador?')) rpc('kick_player', { p_room: S.room.id, p_user: b.dataset.u }); };
  actions.leave = async () => { try { await sb.rpc('leave_room', { p_room: S.room.id }); } catch (_) { /* sin red */ } leaveToCode(); };

  // Menú de juegos
  function buildMenu() {
    if (isAdmin()) {
      screen(`${topbar()}<h2 style="text-align:center">ELIGE UN JUEGO</h2>
        <div class="pgrid">${GAMES.map((g) => `<button class="tile" data-a="game" data-id="${g.id}"><span class="e">${g.emoji}</span>${g.name}</button>`).join('')}</div>
        <div id="gameinfo" class="note"></div>
        <button class="bigbtn" data-a="start" id="startbtn">▶ INICIAR PARTIDA</button>
        <button class="ghost" data-a="tolobby">⬅ Volver a la sala</button>`);
    } else {
      screen(`${topbar()}<div class="stack" style="margin:auto 0;text-align:center"><h2 style="font-size:30px">🎮 El administrador está eligiendo el juego...</h2><div id="gameinfo" class="note"></div></div>`);
    }
  }
  function updMenu() {
    const g = byId(S.room.game_id), n = S.players.length;
    root.querySelectorAll('[data-id]').forEach((b) => b.classList.toggle('sel', b.dataset.id === (g && g.id)));
    const info = $('#gameinfo'); if (info) info.innerHTML = g ? `<b>${g.emoji} ${g.name}</b><br>${esc(g.rules)}` : 'Toca un juego para seleccionarlo.';
    const sb2 = $('#startbtn');
    if (sb2) { sb2.disabled = !g || n < 2; if (n < 2) info.innerHTML += '<br><b>Necesitas al menos 2 jugadores para comenzar.</b>'; }
  }
  actions.game = (b) => rpc('set_room_state', { p_room: S.room.id, p_status: 'menu', p_game: b.dataset.id });
  actions.start = () => rpc('set_room_state', { p_room: S.room.id, p_status: 'playing', p_game: S.room.game_id });
  actions.tolobby = () => rpc('set_room_state', { p_room: S.room.id, p_status: 'lobby' });

  // Partida: mando
  function buildPlaying() {
    const meta = byId(S.room.game_id);
    root.innerHTML = `<div class="ctrl"><div class="hdr"><span>${meta.emoji} ${meta.name}</span><div class="m" id="ctrlmsg">Mira la TV…</div>${isAdmin() ? '<button class="mini" data-a="menu">☰ MENÚ</button>' : ''}</div><div id="ctrlbody" style="flex:1;display:flex;flex-direction:column"></div></div>`;
    const send = (mask) => { if (S.ch) S.ch.send({ type: 'broadcast', event: 'k', payload: { u: me(), m: mask } }); };
    const answer = (c) => { if (S.ch) S.ch.send({ type: 'broadcast', event: 'ans', payload: { u: me(), c } }); };
    S.ctrl = buildController($('#ctrlbody'), meta, { send, answer });
    try { if (navigator.wakeLock) navigator.wakeLock.request('screen').catch(() => {}); } catch (_) { /* opcional */ }
  }
  actions.menu = (b) => {
    if (!S.confirmMenu) { S.confirmMenu = true; b.textContent = '¿SEGURO? TOCA OTRA VEZ'; setTimeout(() => { S.confirmMenu = false; b.textContent = '☰ MENÚ'; }, 3000); return; }
    rpc('set_room_state', { p_room: S.room.id, p_status: 'menu' });
  };

  // Resultados
  async function loadResults() {
    const { data } = await sb.from('game_results').select('*').eq('room_id', S.room.id).order('created_at', { ascending: false }).order('position').limit(8);
    if (!data || !data.length) { S.results = []; return; }
    const t = data[0].created_at; S.results = data.filter((x) => x.created_at === t).sort((a, b) => a.position - b.position);
  }
  function buildResults() {
    screen(`${topbar()}<h2 style="text-align:center;font-size:34px">🏆 RESULTADOS</h2><div id="reslist" class="results"></div>
      ${isAdmin() ? `<button class="bigbtn" data-a="start">🔄 JUGAR OTRA VEZ</button><button class="bigbtn alt" data-a="pick">🎮 ELEGIR OTRO JUEGO</button><button class="ghost danger" data-a="close">🚪 CERRAR SALA</button>` : '<div class="note">Esperando al administrador...</div>'}`);
    loadResults().then(updResults);
  }
  function updResults() {
    const el = $('#reslist'); if (!el) return;
    const medal = ['🥇', '🥈', '🥉'];
    el.innerHTML = S.results.map((r) => `<div class="rrow" style="font-size:20px;padding:12px 16px"><span>${medal[r.position - 1] || r.position + '.º'}</span><span>${esc(r.username)}${r.user_id === me() ? ' (tú)' : ''}</span><span class="sc">${r.score}</span></div>`).join('') || '<div class="note">Cargando…</div>';
  }

  // ---------- Perfil y estadísticas ----------
  actions.profile = async () => {
    const [st, gs] = await Promise.all([sb.from('player_stats').select('*').eq('user_id', me()), sb.from('games').select('*').order('sort')]);
    const rows = st.data || [], names = Object.fromEntries((gs.data || []).map((g) => [g.id, `${g.emoji} ${g.name}`]));
    const tot = rows.reduce((a, r) => ({ played: a.played + r.played, wins: a.wins + r.wins, losses: a.losses + r.losses, points: a.points + Number(r.points), best: Math.max(a.best, r.best) }), { played: 0, wins: 0, losses: 0, points: 0, best: 0 });
    const fav = rows.slice().sort((a, b) => b.played - a.played)[0];
    const ov = document.createElement('div'); ov.className = 'overlay'; ov.id = 'ov';
    ov.innerHTML = `<div class="phone stack"><div class="topbar"><h2 style="flex:1">MI PERFIL</h2><button class="mini" data-a="closeov">✕ Cerrar</button></div>
      <div class="card" style="text-align:center"><small>Usuario</small><h2 style="margin:0;font-size:34px">${esc(S.profile.username)}</h2></div>
      <div class="stat4"><div>Partidas<b>${tot.played}</b></div><div>Victorias<b>${tot.wins}</b></div><div>Derrotas<b>${tot.losses}</b></div><div>Puntos<b>${tot.points.toLocaleString('es')}</b></div><div>Récord<b>${tot.best}</b></div><div>Favorito<b style="font-size:16px">${fav ? names[fav.game_id] || fav.game_id : '—'}</b></div></div>
      <h3>Por juego</h3>
      ${rows.length ? `<table class="st"><tr><th>Juego</th><th>PJ</th><th>V</th><th>Récord</th></tr>${rows.map((r) => `<tr><td>${esc(names[r.game_id] || r.game_id)}</td><td>${r.played}</td><td>${r.wins}</td><td>${r.best}</td></tr>`).join('')}</table>` : '<div class="note">Aún no has jugado partidas.</div>'}</div>`;
    document.body.appendChild(ov);
    ov.addEventListener('click', (e) => { if (e.target.closest('[data-a=closeov]')) ov.remove(); });
  };

  // ---------- Inicio: sesión persistente ----------
  root.innerHTML = '<div class="screen center"><div class="spinner"></div></div>';
  try {
    const { data: { session } } = await sb.auth.getSession();
    if (session && session.user && !session.user.is_anonymous) {
      await loadProfile();
      if (S.profile) {
        const saved = localStorage.getItem('grtv-code');
        if (saved) {
          const { data, error } = await sb.rpc('join_room', { p_code: saved });
          if (!error && data) return enterRoom(data);
          localStorage.removeItem('grtv-code');
        }
        return codeScreen();
      }
    }
  } catch (e) { toast(errText(e)); }
  authChoice();
}
