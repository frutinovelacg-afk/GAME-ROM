import { BIT } from '../games/input.js';

const ARROW = { l: '⬅️', r: '➡️', u: '⬆️', d: '⬇️' };

// Construye el mando del celular según el juego. send(mask) envía el estado de botones; answer(i) responde en el quiz.
export function buildController(host, meta, { send, answer }) {
  const pad = meta.pad;
  let mask = 0, timer = null;

  function setBit(k, on) {
    const nm = on ? mask | BIT[k] : mask & ~BIT[k];
    if (nm === mask) return;
    mask = nm; send(mask);
    if (mask && !timer) timer = setInterval(() => send(mask), 250);
    if (!mask && timer) { clearInterval(timer); timer = null; }
    if (on && navigator.vibrate) navigator.vibrate(12);
  }
  function bindHold(el, k) {
    const up = () => { el.classList.remove('on'); setBit(k, false); };
    el.addEventListener('pointerdown', (e) => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (_) {} el.classList.add('on'); setBit(k, true); });
    el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up); el.addEventListener('lostpointercapture', up);
    el.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  let body;
  if (pad.quiz) {
    body = `<div class="quiz">${['A', 'B', 'C', 'D'].map((l, i) => `<button class="pb" data-q="${i}">${l}</button>`).join('')}</div>`;
  } else {
    const arrows = pad.arrows.split('').map((k) => `<button class="pb" data-k="${k}">${ARROW[k]}</button>`).join('');
    const acts = pad.acts.map(([k, label]) => `<button class="pb" data-k="${k}">${label}</button>`).join('');
    body = `<div class="pad ${acts ? '' : 'one'}"><div class="arrows ${pad.arrows}">${arrows}</div>${acts ? `<div class="acts">${acts}</div>` : ''}</div>`;
  }
  host.innerHTML = body;

  if (pad.quiz) {
    host.querySelectorAll('[data-q]').forEach((b) => b.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      if (host.dataset.locked === '1') return;
      host.dataset.locked = '1';
      host.querySelectorAll('[data-q]').forEach((x) => x.classList.remove('chosen'));
      b.classList.add('chosen'); answer(Number(b.dataset.q));
      if (navigator.vibrate) navigator.vibrate(30);
    }));
  } else host.querySelectorAll('[data-k]').forEach((b) => bindHold(b, b.dataset.k));

  return {
    resetQuiz() { host.dataset.locked = '0'; host.querySelectorAll('[data-q]').forEach((x) => x.classList.remove('chosen')); },
    destroy() { if (timer) clearInterval(timer); if (mask) send(0); mask = 0; },
  };
}
