import './style.css';
import { configured } from './supabase.js';

const root = document.getElementById('app');
window.addEventListener('hashchange', () => location.reload());

function home() {
  root.innerHTML = `
    <div class="screen home">
      <div class="bubbles"><i></i><i></i><i></i></div>
      <div class="hero">
        <h1>GAME ROOM TV</h1>
        <p>Convierte tu celular en un control y juega con tus amigos.</p>
      </div>
      <div class="choices">
        <button class="bigbtn" data-go="#/phone" autofocus><span>📱</span> SOY CELULAR</button>
        <button class="bigbtn alt" data-go="#/tv"><span>📺</span> SOY LA TV</button>
      </div>
    </div>`;
  root.onclick = (e) => {
    const b = e.target.closest('[data-go]');
    if (b) location.hash = b.dataset.go;
  };
  const f = root.querySelector('[data-go]');
  if (f) f.focus();
}

if (!configured) {
  root.innerHTML = `<div class="screen center"><div class="card narrow">
    <h2>Falta configurar Supabase</h2>
    <p>Define <b>VITE_SUPABASE_URL</b> y <b>VITE_SUPABASE_ANON_KEY</b> (archivo .env en local, o variables de entorno en Netlify) y vuelve a compilar.</p></div></div>`;
} else if (location.hash === '#/tv') {
  import('./tv/tv.js').then((m) => m.startTV(root));
} else if (location.hash === '#/phone') {
  import('./phone/phone.js').then((m) => m.startPhone(root));
} else {
  home();
}
