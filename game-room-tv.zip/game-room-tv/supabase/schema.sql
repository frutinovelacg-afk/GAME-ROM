-- =====================================================================
-- GAME ROOM TV — esquema completo (ejecutar entero en Supabase > SQL Editor)
-- =====================================================================
create extension if not exists pgcrypto;

-- ---------- TABLAS ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  created_at timestamptz not null default now(),
  constraint username_fmt check (username ~ '^[A-Za-z0-9_]{3,16}$')
);
create unique index if not exists profiles_username_ci on public.profiles (lower(username));

create table if not exists public.games (
  id text primary key,
  name text not null,
  emoji text not null,
  min_players int not null default 2,
  max_players int not null default 4,
  sort int not null default 0
);

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null,
  tv_id uuid not null,
  admin_id uuid references public.profiles(id) on delete set null,
  status text not null default 'lobby' check (status in ('lobby','menu','playing','results')),
  game_id text references public.games(id),
  closed boolean not null default false,
  created_at timestamptz not null default now()
);
create unique index if not exists rooms_code_open on public.rooms (code) where not closed;

create table if not exists public.room_players (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null,
  is_admin boolean not null default false,
  last_seen timestamptz not null default now(),
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table if not exists public.room_kicks (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null,
  primary key (room_id, user_id)
);

create table if not exists public.player_stats (
  user_id uuid not null references public.profiles(id) on delete cascade,
  game_id text not null references public.games(id),
  played int not null default 0,
  wins int not null default 0,
  losses int not null default 0,
  points bigint not null default 0,
  best int not null default 0,
  primary key (user_id, game_id)
);

create table if not exists public.game_results (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.rooms(id) on delete cascade,
  game_id text not null references public.games(id),
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null,
  score int not null,
  position int not null,
  created_at timestamptz not null default now()
);

create table if not exists public.chat_messages (
  id bigint generated always as identity primary key,
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null,
  body text not null check (char_length(body) between 1 and 140),
  created_at timestamptz not null default now()
);
create index if not exists chat_room_idx on public.chat_messages (room_id, id);

insert into public.games (id, name, emoji, sort) values
 ('carrera','CARRERA','🏎️',1),('penales','PENALES','⚽',2),('partido','PARTIDO','⚽',3),
 ('tiro','TIRO AL BLANCO','🎯',4),('quiz','QUIZ','🧠',5),('obstaculos','EVITAR OBSTÁCULOS','🚧',6),
 ('snake','SNAKE','🐍',7),('infinita','CARRERA INFINITA','🏃',8),('monedas','ATRAPA MONEDAS','🪙',9),
 ('bloques','ROMPE BLOQUES','🧱',10),('nave','NAVE ESPACIAL','🚀',11),('pong','PONG','🏓',12)
on conflict (id) do nothing;

-- ---------- PERFIL AUTOMÁTICO AL REGISTRARSE ----------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(new.is_anonymous, false) then return new; end if;   -- las TVs son anónimas: sin perfil
  insert into public.profiles (id, username) values (new.id, new.raw_user_meta_data->>'username');
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- AYUDANTE RLS ----------
create or replace function public.is_room_member(rid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from room_players where room_id = rid and user_id = auth.uid())
      or exists (select 1 from rooms where id = rid and tv_id = auth.uid());
$$;

-- ---------- ROW LEVEL SECURITY ----------
alter table public.profiles enable row level security;
alter table public.games enable row level security;
alter table public.rooms enable row level security;
alter table public.room_players enable row level security;
alter table public.room_kicks enable row level security;
alter table public.player_stats enable row level security;
alter table public.game_results enable row level security;
alter table public.chat_messages enable row level security;

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (true);
drop policy if exists games_read on public.games;
create policy games_read on public.games for select to authenticated using (true);
drop policy if exists rooms_read on public.rooms;
create policy rooms_read on public.rooms for select to authenticated using (public.is_room_member(id));
drop policy if exists players_read on public.room_players;
create policy players_read on public.room_players for select to authenticated using (public.is_room_member(room_id));
drop policy if exists stats_read on public.player_stats;
create policy stats_read on public.player_stats for select to authenticated using (user_id = auth.uid());
drop policy if exists results_read on public.game_results;
create policy results_read on public.game_results for select to authenticated
  using (user_id = auth.uid() or public.is_room_member(room_id));
drop policy if exists chat_read on public.chat_messages;
create policy chat_read on public.chat_messages for select to authenticated using (public.is_room_member(room_id));
drop policy if exists chat_write on public.chat_messages;
create policy chat_write on public.chat_messages for insert to authenticated
  with check (
    user_id = auth.uid()
    and exists (select 1 from public.room_players rp where rp.room_id = chat_messages.room_id and rp.user_id = auth.uid() and rp.username = chat_messages.username)
  );
-- Sin políticas de escritura en el resto: solo se modifican mediante las funciones de abajo.

-- ---------- FUNCIONES (RPC) ----------
create or replace function public._remove_player(rid uuid, uid uuid) returns void
language plpgsql security definer set search_path = public as $$
declare nxt uuid;
begin
  delete from room_players where room_id = rid and user_id = uid;
  if exists (select 1 from rooms where id = rid and admin_id = uid) then
    select user_id into nxt from room_players where room_id = rid order by joined_at limit 1;
    update room_players set is_admin = (user_id = nxt) where room_id = rid;
    update rooms set admin_id = nxt where id = rid;
  end if;
  if not exists (select 1 from room_players where room_id = rid) then
    update rooms set status = 'lobby', game_id = null where id = rid;
  end if;
end $$;
revoke all on function public._remove_player(uuid, uuid) from public, anon, authenticated;

create or replace function public.create_room() returns public.rooms
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; c text; r public.rooms; i int;
begin
  if uid is null then raise exception 'No autenticado'; end if;
  if exists (select 1 from profiles where id = uid) then raise exception 'Solo una TV puede crear salas'; end if;
  delete from rooms where created_at < now() - interval '2 days';
  update rooms set closed = true where tv_id = uid and not closed;
  loop
    c := '';
    for i in 1..4 loop c := c || substr(chars, 1 + floor(random() * 32)::int, 1); end loop;
    begin
      insert into rooms (code, tv_id) values (c, uid) returning * into r;
      exit;
    exception when unique_violation then null;
    end;
  end loop;
  return r;
end $$;

create or replace function public.join_room(p_code text) returns public.rooms
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); r public.rooms; me public.profiles; n int; old record;
begin
  select * into me from profiles where id = uid;
  if me.id is null then raise exception 'Inicia sesión primero'; end if;
  select * into r from rooms where code = upper(trim(p_code)) and not closed for update;
  if r.id is null then raise exception 'Código de sala no válido'; end if;
  if exists (select 1 from room_kicks where room_id = r.id and user_id = uid) then
    raise exception 'Fuiste expulsado de esta sala';
  end if;
  if exists (select 1 from room_players where room_id = r.id and user_id = uid) then
    update room_players set last_seen = now() where room_id = r.id and user_id = uid;
    return r;
  end if;
  for old in select room_id from room_players where user_id = uid loop
    perform public._remove_player(old.room_id, uid);
  end loop;
  select count(*) into n from room_players where room_id = r.id;
  if n >= 4 then raise exception 'La sala está llena (4/4)'; end if;
  if r.status = 'playing' then raise exception 'La partida ya empezó. Espera a que termine.'; end if;
  insert into room_players (room_id, user_id, username, is_admin) values (r.id, uid, me.username, n = 0);
  if n = 0 then update rooms set admin_id = uid where id = r.id returning * into r; end if;
  return r;
end $$;

create or replace function public.leave_room(p_room uuid) returns void
language plpgsql security definer set search_path = public as $$
begin perform public._remove_player(p_room, auth.uid()); end $$;

create or replace function public.kick_player(p_room uuid, p_user uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from rooms where id = p_room and admin_id = auth.uid()) then
    raise exception 'Solo el administrador puede expulsar';
  end if;
  if p_user = auth.uid() then raise exception 'No puedes expulsarte a ti mismo'; end if;
  insert into room_kicks (room_id, user_id) values (p_room, p_user) on conflict do nothing;
  perform public._remove_player(p_room, p_user);
end $$;

create or replace function public.set_room_state(p_room uuid, p_status text, p_game text default null) returns void
language plpgsql security definer set search_path = public as $$
declare r public.rooms; g public.games; n int; gid text;
begin
  select * into r from rooms where id = p_room and not closed;
  if r.id is null then raise exception 'Sala no disponible'; end if;
  if r.admin_id is distinct from auth.uid() then raise exception 'Solo el administrador puede hacer esto'; end if;
  if p_status not in ('lobby','menu','playing') then raise exception 'Estado no válido'; end if;
  gid := coalesce(p_game, r.game_id);
  if p_game is not null and not exists (select 1 from games where id = p_game) then raise exception 'Juego no válido'; end if;
  if p_status = 'playing' then
    select count(*) into n from room_players where room_id = p_room;
    if n < 2 then raise exception 'Necesitas al menos 2 jugadores para comenzar.'; end if;
    if gid is null then raise exception 'Elige un juego primero'; end if;
    select * into g from games where id = gid;
    if n < g.min_players or n > g.max_players then raise exception 'Este juego admite de % a % jugadores', g.min_players, g.max_players; end if;
  end if;
  update rooms set status = p_status, game_id = gid where id = p_room;
end $$;

create or replace function public.touch_player(p_room uuid) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update room_players set last_seen = now() where room_id = p_room and user_id = auth.uid();
  return found;
end $$;

create or replace function public.prune_players(p_room uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r public.rooms; x record;
begin
  select * into r from rooms where id = p_room and tv_id = auth.uid() and not closed;
  if r.id is null or r.status = 'playing' then return; end if;
  for x in select user_id from room_players where room_id = p_room and last_seen < now() - interval '40 seconds' loop
    perform public._remove_player(p_room, x.user_id);
  end loop;
end $$;

create or replace function public.close_room(p_room uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from rooms where id = p_room and (admin_id = auth.uid() or tv_id = auth.uid())) then
    raise exception 'Sin permiso';
  end if;
  update rooms set closed = true where id = p_room;
  delete from room_players where room_id = p_room;
end $$;

create or replace function public.finish_game(p_room uuid, p_results jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare r public.rooms; rec record;
begin
  select * into r from rooms where id = p_room and tv_id = auth.uid() and not closed;
  if r.id is null then raise exception 'Solo la TV de la sala puede enviar resultados'; end if;
  if r.status <> 'playing' then return; end if;
  for rec in
    with raw as (
      select (e->>'user_id')::uuid as uid, least(greatest((e->>'score')::int, 0), 1000000) as score
      from jsonb_array_elements(p_results) e
    ),
    valid as (
      select w.uid, w.score, rp.username from raw w
      join room_players rp on rp.room_id = p_room and rp.user_id = w.uid
    )
    select uid, score, username, rank() over (order by score desc)::int as pos from valid
  loop
    insert into game_results (room_id, game_id, user_id, username, score, position)
    values (p_room, r.game_id, rec.uid, rec.username, rec.score, rec.pos);
    insert into player_stats (user_id, game_id, played, wins, losses, points, best)
    values (rec.uid, r.game_id, 1, (rec.pos = 1)::int, (rec.pos <> 1)::int, rec.score, rec.score)
    on conflict (user_id, game_id) do update set
      played = player_stats.played + 1,
      wins = player_stats.wins + excluded.wins,
      losses = player_stats.losses + excluded.losses,
      points = player_stats.points + excluded.points,
      best = greatest(player_stats.best, excluded.best);
  end loop;
  update rooms set status = 'results' where id = p_room;
end $$;

-- ---------- REALTIME ----------
do $$ begin alter publication supabase_realtime add table public.rooms; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.room_players; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.chat_messages; exception when others then null; end $$;
alter table public.rooms replica identity full;
alter table public.room_players replica identity full;
